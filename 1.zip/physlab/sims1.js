/* ===== محاكاة 1: الجاذبية، المقذوفات، النواس، النابض، نيوتن، الاحتكاك، التصادم ===== */
const PLANETS = { earth: ['الأرض', 9.81, '#4cc9f0'], moon: ['القمر', 1.62, '#c9d1d9'], mars: ['المريخ', 3.73, '#ff7b54'], jupiter: ['المشتري', 24.79, '#e0a96d'], venus: ['الزهرة', 8.87, '#f4d35e'] };

SIMS.gravity = (root, pre) => {
  let cols = [], single = pre.planets.length === 1, T = 0;
  let rd = {};
  return Sim(root, {
    h: 430, hm: 430,
    init(S) {
      if (single) S.select('planet', 'الكوكب', Object.entries(PLANETS).map(([k, v]) => [k, v[0] + ' (' + v[1] + ' م/ث²)']), pre.planets[0]);
      S.slider('m', 'كتلة الكرة', 1, 10, 1, 3, 'كجم', { d: 0 });
      if (pre.mode === 'measure') S.slider('h', 'ارتفاع السقوط', 5, 50, 1, 20, 'م', { d: 0, reset: true });
      else S.p.h = 20;
      if (pre.mode === 'weight') pre.planets.forEach(k => rd[k] = S.read('وزن الكرة على ' + PLANETS[k][0], 'نيوتن'));
      else { rd.t = S.read('زمن السقوط', 'ث'); rd.v = S.read('السرعة اللحظية', 'م/ث'); rd.w = S.read('الوزن', 'نيوتن'); if (pre.mode === 'measure') rd.g = S.read('g المحسوبة = 2h/t²', 'م/ث²', 'hi'); }
      S.note(pre.mode === 'weight' ? 'الوزن = الكتلة × تسارع الجاذبية. الكتلة ثابتة في كل مكان أما الوزن فيتغير من كوكب لآخر.' : pre.mode === 'measure' ? 'قِس زمن السقوط ثم احسب g من العلاقة g = 2h / t².' : 'جميع الأجسام تسقط بنفس التسارع مهما اختلفت كتلها (بإهمال مقاومة الهواء).');
    },
    reset(S) { cols = (single ? [S.p.planet || pre.planets[0]] : pre.planets).map(k => ({ k, n: PLANETS[k][0], g: PLANETS[k][1], c: PLANETS[k][2], t: 0, done: false })); },
    onParam(S, k) { if (k === 'planet' || k === 'h') { } },
    step(S, dt) {
      cols.forEach(c => { if (!c.done) { c.t += dt; if (.5 * c.g * c.t * c.t >= S.p.h) { c.t = Math.sqrt(2 * S.p.h / c.g); c.done = true; c.T = c.t; } } });
      if (cols.every(c => c.done)) S.setRun(false);
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H);
      const top = 70, ground = H - 50, sc = (ground - top) / S.p.h, n = cols.length;
      cols.forEach((c, i) => {
        const x = (i + .5) * W / n, y = Math.min(S.p.h, .5 * c.g * c.t * c.t), v = c.done ? Math.sqrt(2 * c.g * S.p.h) : c.g * c.t;
        text(ctx, c.n, x, 24, { size: 16, weight: 700, color: c.c }); text(ctx, 'g = ' + c.g + ' م/ث²', x, 44, { size: 12, color: COL.dim });
        ctx.fillStyle = c.c + '55'; ctx.fillRect(x - 70, ground + 10, 140, 8);
        ctx.strokeStyle = COL.grid; ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x, ground); ctx.stroke(); ctx.setLineDash([]);
        for (let tt = .5; tt < c.t; tt += .5) { const yy = .5 * c.g * tt * tt; if (yy < S.p.h) { ctx.fillStyle = 'rgba(255,255,255,.28)'; ctx.beginPath(); ctx.arc(x, top + yy * sc, 5, 0, TAU); ctx.fill(); } }
        const r = 10 + S.p.m * 1.8; ctx.fillStyle = c.c; ctx.beginPath(); ctx.arc(x, top + y * sc - 0 + 0, r, 0, TAU); ctx.fill();
        text(ctx, S.p.m + ' كجم', x, top + y * sc, { color: '#06101f', size: 11, weight: 700 });
        if (pre.mode === 'weight') arrow(ctx, x, top + y * sc + r, x, top + y * sc + r + 6 + S.p.m * c.g * .5, COL.d, 3);
        if (pre.mode === 'weight') text(ctx, 'W = ' + fmt(S.p.m * c.g, 1) + ' N', x + 60, ground - 20, { color: COL.d, size: 13, weight: 700 });
        if (pre.mode === 'weight') rd[c.k](S.p.m * c.g, 1);
        else if (i === 0) { rd.t(c.t); rd.v(v); rd.w(S.p.m * c.g); if (rd.g) rd.g(c.done ? 2 * S.p.h / (c.t * c.t) : '—'); }
      });
      text(ctx, 'المسافة المقطوعة كل 0.5 ثانية', W - 110, H - 14, { size: 11, color: COL.dim });
    }
  });
};

SIMS.projectile = (root, pre) => {
  let tr = [], hit = false; const g = 9.81;
  const par = S => { const a = (pre.mode === 'vertical' ? 90 : pre.mode === 'horizontal' ? 0 : S.p.ang) * D2R, v = S.p.v, h = pre.mode === 'horizontal' ? S.p.h : (S.p.h0 || 0); const vy = v * Math.sin(a); const T = (vy + Math.sqrt(vy * vy + 2 * g * h)) / g; return { a, v, h, vx: v * Math.cos(a), vy, T, H: h + (vy > 0 ? vy * vy / (2 * g) : 0) }; };
  let rd = {};
  return Sim(root, {
    h: 420, hm: 460,
    init(S) {
      S.slider('v', pre.mode === 'horizontal' ? 'السرعة الأفقية' : 'سرعة الإطلاق', 0, 40, 1, pre.mode === 'vertical' ? 20 : pre.mode === 'horizontal' ? 12 : 22, 'م/ث', { d: 0 });
      if (pre.mode === 'free' || !pre.mode) S.slider('ang', 'زاوية الإطلاق', 5, 85, 1, 45, '°', { d: 0 });
      if (pre.mode === 'horizontal') S.slider('h', 'ارتفاع الإطلاق', 5, 60, 1, 30, 'م', { d: 0 });
      rd.T = S.read('زمن التحليق', 'ث'); rd.H = S.read('أقصى ارتفاع', 'م'); if (pre.mode !== 'vertical') rd.R = S.read('المدى الأفقي', 'م'); rd.vv = S.read('السرعة اللحظية', 'م/ث');
      S.note(pre.mode === 'vertical' ? 'عند أعلى نقطة تنعدم السرعة الرأسية لحظياً بينما يبقى تسارع الجاذبية 9.81 م/ث² نحو الأسفل.' : pre.mode === 'horizontal' ? 'الحركة الأفقية منتظمة والحركة الرأسية بتسارع الجاذبية، وهما مستقلتان؛ لذلك يهبط الجسم بنفس زمن السقوط الحر.' : 'أكبر مدى أفقي عند زاوية 45° (عندما يكون الإطلاق من سطح الأرض).');
    },
    reset(S) { tr = []; },
    onParam(S) { },
    step(S, dt) { const p = par(S); if (S.t >= p.T) { S.t = p.T; S.setRun(false); } },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H); const p = par(S);
      const R = p.vx * p.T, ground = H - 40, left = 50;
      const sc = Math.min((W - 100) / Math.max(R, 8), (ground - 40) / Math.max(p.H, 8));
      const gx = x => left + x * sc, gy = y => ground - y * sc;
      ctx.fillStyle = '#1d3a2a'; ctx.fillRect(0, ground, W, 40);
      if (pre.mode === 'horizontal') { ctx.fillStyle = '#31496e'; ctx.fillRect(0, gy(p.h), left + 4, ground - gy(p.h)); }
      ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.setLineDash([5, 6]); ctx.beginPath();
      for (let t = 0; t <= p.T + .001; t += p.T / 60) { const x = p.vx * t, y = p.h + p.vy * t - .5 * g * t * t; t ? ctx.lineTo(gx(x), gy(y)) : ctx.moveTo(gx(x), gy(y)); } ctx.stroke(); ctx.setLineDash([]);
      const t = S.t, x = p.vx * t, y = Math.max(0, p.h + p.vy * t - .5 * g * t * t);
      for (let k = .5; k < t; k += .5) { const xx = p.vx * k, yy = p.h + p.vy * k - .5 * g * k * k; ctx.fillStyle = 'rgba(255,181,71,.5)'; ctx.beginPath(); ctx.arc(gx(xx), gy(yy), 4, 0, TAU); ctx.fill(); }
      const vx = p.vx, vy = p.vy - g * t; ctx.fillStyle = COL.a; ctx.beginPath(); ctx.arc(gx(x), gy(y), 9, 0, TAU); ctx.fill();
      if (!(pre.mode === 'vertical')) arrow(ctx, gx(x), gy(y), gx(x) + vx * 3, gy(y), COL.b, 2.5);
      arrow(ctx, gx(x), gy(y), gx(x), gy(y) - vy * 3, COL.c, 2.5);
      rd.T(p.T); rd.H(p.H); rd.R && rd.R(R); rd.vv(Math.hypot(vx, vy));
      text(ctx, 'السهم الأزرق: السرعة الأفقية   |   السهم الأخضر: السرعة الرأسية', W / 2, 18, { size: 11, color: COL.dim });
    }
  });
};

SIMS.pendulum = (root, pre) => {
  const g = 9.81; let P = [], gr = new Graph(), T0 = [0, 0], last = [null, null], Tm = [null, null], rd = {};
  const prm = (S, i) => ({ L: i && pre.focus === 'len' ? S.p.L2 : S.p.L, amp: i && pre.focus === 'amp' ? S.p.A2 : S.p.A, m: i && pre.focus === 'mass' ? S.p.m2 : S.p.m });
  const n = () => pre.focus ? 2 : 1;
  return Sim(root, {
    h: 440, hm: 600, auto: true,
    init(S) {
      S.slider('L', pre.focus === 'len' ? 'طول الخيط (النواس الأول)' : 'طول الخيط', .3, 2, .05, 1, 'م');
      S.slider('A', pre.focus === 'amp' ? 'السعة (النواس الأول)' : 'سعة الاهتزاز', 5, 80, 1, 20, '°', { d: 0 });
      S.slider('m', pre.focus === 'mass' ? 'الكتلة (النواس الأول)' : 'كتلة الثقل', .1, 5, .1, 1, 'كجم', { d: 1 });
      if (pre.focus === 'len') S.slider('L2', 'طول الخيط (النواس الثاني)', .3, 2, .05, 1.6, 'م');
      if (pre.focus === 'amp') S.slider('A2', 'السعة (النواس الثاني)', 5, 80, 1, 50, '°', { d: 0 });
      if (pre.focus === 'mass') S.slider('m2', 'الكتلة (النواس الثاني)', .1, 5, .1, 4, 'كجم', { d: 1 });
      S.select('graph', 'المنحنى', [['x', 'الإزاحة الزاوية θ'], ['v', 'السرعة الخطية v'], ['a', 'التسارع المماسي a']], pre.graph || 'x');
      rd.T1 = S.read('الزمن الدوري المقاس T', 'ث'); rd.Tt = S.read('T النظري = 2π√(L/g)', 'ث'); rd.f = S.read('التردد f', 'هرتز');
      if (pre.focus) { rd.T2 = S.read('T للنواس الثاني', 'ث', 'alt'); }
      S.note(pre.focus === 'mass' ? 'غيّر الكتلة وراقب: الزمن الدوري لا يعتمد على كتلة الثقل.' : pre.focus === 'amp' ? 'للسعات الصغيرة (أقل من نحو 15°) لا يتغير الزمن الدوري مع السعة تقريباً، ويكبر قليلاً عند السعات الكبيرة.' : pre.focus === 'len' ? 'كلما زاد الطول زاد الزمن الدوري؛ T تتناسب مع √L.' : 'الإزاحة θ = θ₀ cos(ωt) ، السرعة v = −Lθ₀ω sin(ωt) ، التسارع a = −Lθ₀ω² cos(ωt) للسعات الصغيرة.');
    },
    reset(S) {
      P = [0, 1].slice(0, n()).map(i => ({ th: prm(S, i).amp * D2R, w: 0 }));
      gr.clear(); last = [null, null]; Tm = [null, null];
    },
    onParam(S, k) { if (k !== 'graph') S.reset(); else gr.clear(); },
    step(S, dt) {
      P.forEach((p, i) => {
        const L = prm(S, i).L, a = -(g / L) * Math.sin(p.th);
        p.w += a * dt; const old = p.th; p.th += p.w * dt;
        if (old < 0 && p.th >= 0) { if (last[i] != null) Tm[i] = S.t - last[i]; last[i] = S.t; }
      });
      if (S.t > 12) { }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0);
      const wide = W >= 640, sw = wide ? W * .45 : W, sh = wide ? H : H * .5;
      const piv = [{ x: sw * (n() === 2 ? .3 : .5), y: 36 }, { x: sw * .7, y: 36 }], sc = (sh - 90) / 2.1;
      ctx.fillStyle = '#31496e'; ctx.fillRect(10, 26, sw - 20, 10);
      P.forEach((p, i) => {
        const q = prm(S, i), px = piv[i].x, py = piv[i].y, bx = px + q.L * sc * Math.sin(p.th), by = py + q.L * sc * Math.cos(p.th), r = 9 + q.m * 3.2;
        ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px, py + q.L * sc); ctx.stroke(); ctx.setLineDash([]);
        ctx.strokeStyle = '#dbe7ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(bx, by); ctx.stroke();
        ctx.fillStyle = i ? COL.b : COL.a; ctx.beginPath(); ctx.arc(bx, by, r, 0, TAU); ctx.fill();
        text(ctx, fmt(q.m, 1) + ' كجم', bx, by, { size: 10, color: '#06101f', weight: 700 });
        ctx.strokeStyle = (i ? COL.b : COL.a) + '55'; ctx.beginPath(); ctx.arc(px, py, q.L * sc, Math.PI / 2 - q.amp * D2R, Math.PI / 2 + q.amp * D2R); ctx.stroke();
        const L = q.L, w = p.w, th = p.th;
        const val = S.p.graph === 'x' ? th / D2R : S.p.graph === 'v' ? L * w : -g * Math.sin(th);
        if (S.running) gr.add(i, S.t % 12, val);
        rd[i ? 'T2' : 'T1'] && rd[i ? 'T2' : 'T1'](Tm[i] ?? '—'); if (!i) { rd.Tt(2 * Math.PI * Math.sqrt(L / g)); rd.f(Tm[0] ? 1 / Tm[0] : '—'); }
      });
      if (S.t % 12 < .02 && S.running && S.t > 1) gr.clear();
      const gx = wide ? sw : 0, gy = wide ? 0 : sh, gw = wide ? W - sw : W, gh = wide ? H : H - sh;
      gr.draw(ctx, gx + 8, gy + 8, gw - 16, gh - 16, { x0: 0, x1: 12, title: S.p.graph === 'x' ? 'الإزاحة الزاوية (°) — الزمن (ث)' : S.p.graph === 'v' ? 'السرعة (م/ث) — الزمن (ث)' : 'التسارع (م/ث²) — الزمن (ث)', colors: [COL.a, COL.b] });
    }
  });
};

SIMS.spring = (root, pre) => {
  const g = 9.81; let gr = new Graph(), pts = [], rd = {}, saved = [];
  const bal = pre.mode === 'balance';
  return Sim(root, {
    h: 450, hm: 620, auto: !bal,
    init(S) {
      S.slider('k', 'ثابت النابض k', bal ? 15 : 5, 100, 1, bal ? 20 : 25, 'N/m', { d: 0 });
      S.slider('m', 'الكتلة المعلّقة', bal ? 0 : .1, bal ? 2 : 3, bal ? .05 : .05, bal ? .5 : 1, 'كجم', { d: 2 });
      if (!bal) { S.slider('A', 'السعة', .02, .2, .01, .1, 'م'); S.select('graph', 'المنحنى', [['x', 'الإزاحة x'], ['v', 'السرعة v'], ['a', 'التسارع a']], pre.graph || 'x'); rd.T = S.read('الزمن الدوري T = 2π√(m/k)', 'ث'); rd.f = S.read('التردد f', 'هرتز'); rd.x = S.read('الإزاحة x', 'م'); rd.v = S.read('السرعة v', 'م/ث'); rd.a = S.read('التسارع a', 'م/ث²'); S.note('x = A cos ωt ، v = −Aω sin ωt ، a = −Aω² cos ωt  حيث ω = √(k/m). لاحظ أن التسارع يتناسب عكسياً مع الإزاحة.'); }
      else {
        rd.F = S.read('القوة F = m·g', 'نيوتن'); rd.x = S.read('الاستطالة x = F/k', 'سم'); rd.k = S.read('ثابت النابض k = F/x', 'N/m');
        S.btn('✚ سجّل القياس', () => { const x = S.p.m * g / S.p.k; saved.push([x * 100, S.p.m * g]); saved.sort((a, b) => a[0] - b[0]); gr.s[0] = saved.slice(); });
        S.note('قانون هوك: القوة المؤثرة على النابض تتناسب طرديًا مع استطالته F = k·x. اضغط «سجّل القياس» بعد تغيير الكتلة لتحصل على الخط البياني.');
      }
    },
    reset(S) { gr.clear(); saved = []; if (bal) { gr.s[0] = []; } },
    onParam(S, k) { if (k === 'graph') gr.clear(); if (!bal && k !== 'graph') { gr.clear(); } },
    step(S, dt) { if (!bal) { const w = Math.sqrt(S.p.k / S.p.m), t = S.t; gr.add(0, t % 10, S.p.graph === 'x' ? S.p.A * Math.cos(w * t) : S.p.graph === 'v' ? -S.p.A * w * Math.sin(w * t) : -S.p.A * w * w * Math.cos(w * t)); if (t % 10 < dt * 1.5 && t > 5) { gr.clear(); } } },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0);
      const wide = W >= 640, sw = wide ? W * .42 : W, sh = wide ? H : H * .55;
      const px = sw / 2, top = 30, scl = bal ? 170 : 380;
      ctx.fillStyle = '#31496e'; ctx.fillRect(px - 60, top - 12, 120, 12);
      let x, v = 0, a = 0;
      if (bal) { const xe = S.p.m * g / S.p.k; const t = S.running ? S.t : 99; const ww = 7; x = xe * (1 - Math.exp(-2.5 * t) * Math.cos(ww * t)); if (!S.running && S.t === 0) x = xe; }
      else { const w = Math.sqrt(S.p.k / S.p.m); x = S.p.A * Math.cos(w * S.t); v = -S.p.A * w * Math.sin(w * S.t); a = -S.p.A * w * w * Math.cos(w * S.t); }
      const L0 = bal ? 0.55 : 0.5, eq = bal ? 0 : S.p.m * g / S.p.k, len = L0 + eq + x;
      const y1 = top, y2 = top + len * scl * (bal ? .9 : .75) * (bal ? 1 : 1);
      ctx.strokeStyle = '#cfe3ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(px, y1);
      const turns = 14, seg = (y2 - 20 - y1) / turns; for (let i = 0; i < turns; i++) { ctx.lineTo(px + (i % 2 ? -16 : 16), y1 + 10 + seg * (i + .5)); } ctx.lineTo(px, y2 - 20); ctx.stroke();
      const bw = 34 + S.p.m * 14; rrect(ctx, px - bw / 2, y2 - 20, bw, 40, 6, COL.a); text(ctx, fmt(S.p.m, 2) + ' كجم', px, y2, { color: '#06101f', size: 12, weight: 700 });
      if (bal) {
        const y0 = top + L0 * scl * .9;
        ctx.fillStyle = '#e8f1ff22'; ctx.fillRect(px + 70, y0, 14, 20 * 0.01 * 100 * scl * .9);
        for (let c = 0; c <= 100; c += 10) { const yy = y0 + c / 100 * scl * .9; ctx.fillStyle = COL.dim; ctx.fillRect(px + 70, yy, 14, 1.5); text(ctx, String(c), px + 100, yy, { size: 10, color: COL.dim }); }
        text(ctx, 'سم', px + 100, y0 - 14, { size: 10, color: COL.dim });
        ctx.strokeStyle = COL.d; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(px + 60, y2 - 20); ctx.lineTo(px + 84, y2 - 20); ctx.stroke();
        rd.F(S.p.m * g); rd.x(S.p.m * g / S.p.k * 100); rd.k(S.p.m > 0 ? S.p.k : '—', 0);
        const gx = wide ? sw : 0, gy = wide ? 0 : sh, gw = wide ? W - sw : W, gh = wide ? H : H - sh;
        const o = gr.draw(ctx, gx + 8, gy + 8, gw - 16, gh - 16, { x0: 0, x1: 100, y0: 0, y1: 20, title: 'القوة F (نيوتن) — الاستطالة x (سم)' });
        ctx.fillStyle = COL.d; saved.forEach(p => { ctx.beginPath(); ctx.arc(o.sx(p[0]), o.sy(p[1]), 5, 0, TAU); ctx.fill(); });
      } else {
        arrow(ctx, px - bw / 2 - 18, y2, px - bw / 2 - 18, y2 + Math.sign(-a || 1) * Math.min(60, Math.abs(a) * 4) * -1, COL.d, 2.5);
        rd.T(2 * Math.PI * Math.sqrt(S.p.m / S.p.k)); rd.f(1 / (2 * Math.PI * Math.sqrt(S.p.m / S.p.k))); rd.x(x); rd.v(v); rd.a(a);
        const gx = wide ? sw : 0, gy = wide ? 0 : sh, gw = wide ? W - sw : W, gh = wide ? H : H - sh;
        const A = S.p.A, w = Math.sqrt(S.p.k / S.p.m), lim = S.p.graph === 'x' ? A : S.p.graph === 'v' ? A * w : A * w * w;
        gr.draw(ctx, gx + 8, gy + 8, gw - 16, gh - 16, { x0: 0, x1: 10, y0: -lim * 1.15, y1: lim * 1.15, title: S.p.graph === 'x' ? 'الإزاحة (م) — الزمن (ث)' : S.p.graph === 'v' ? 'السرعة (م/ث) — الزمن (ث)' : 'التسارع (م/ث²) — الزمن (ث)' });
      }
    }
  });
};

SIMS.newton = (root, pre) => {
  let c = [], rd = {}; const g = 9.8, mode = pre.mode;
  return Sim(root, {
    h: mode === 'second' ? 360 : 330, hm: mode === 'second' ? 420 : 360,
    init(S) {
      if (mode === 'second') {
        S.slider('m1', 'كتلة المكوك الأول', 50, 500, 10, 100, 'كجم', { d: 0 }); S.slider('F1', 'قوة الدفع على الأول', 1, 300, 1, 50, 'N', { d: 0 });
        S.slider('m2', 'كتلة المكوك الثاني', 50, 500, 10, 400, 'كجم', { d: 0 }); S.slider('F2', 'قوة الدفع على الثاني', 1, 300, 1, 50, 'N', { d: 0 });
        rd.a1 = S.read('تسارع الأول a₁ = F/m', 'م/ث²'); rd.a2 = S.read('تسارع الثاني a₂ = F/m', 'م/ث²');
        S.note('عند ثبات القوة يتناسب التسارع عكسيًا مع الكتلة. جرّب جعل F₂ = 200 نيوتن مع m₂ = 400 كجم لتحصل على التسارع نفسه.');
      } else if (mode === 'define') {
        S.slider('m1', 'الكتلة', .5, 5, .5, 1, 'كجم', { d: 1 }); S.slider('F1', 'القوة', .5, 10, .5, 1, 'N', { d: 1 });
        rd.a1 = S.read('التسارع a = F/m', 'م/ث²', 'hi');
        S.note('النيوتن هو القوة التي تكسب كتلة مقدارها 1 كجم تسارعًا مقداره 1 م/ث². 1 N = 1 كجم·م/ث².');
      } else if (mode === 'first') {
        S.slider('m1', 'الكتلة', 1, 10, .5, 2, 'كجم', { d: 1 }); S.slider('v0', 'السرعة الابتدائية', 0, 10, .5, pre.balanced ? 2 : 4, 'م/ث', { d: 1 });
        S.slider('F', 'قوة الدفع الأمامية', 0, 40, .1, pre.balanced ? 4.9 : 0, 'N', { d: 1 }); S.slider('mu', 'معامل الاحتكاك', 0, .5, .05, pre.balanced ? .25 : 0, '', { d: 2 });
        rd.fnet = S.read('محصلة القوى', 'N', 'hi'); rd.v = S.read('السرعة الحالية', 'م/ث'); rd.x = S.read('المسافة المقطوعة', 'م');
        S.note(pre.balanced ? 'عندما تتساوى قوة الدفع مع الاحتكاك تصبح المحصلة صفرًا فيتحرك الجسم بسرعة ثابتة: توازن حركي. وإذا كانت السرعة صفرًا فهو توازن ساكن.' : 'قانون نيوتن الأول: يبقى الجسم على حالته (ساكنًا أو متحركًا بسرعة ثابتة) ما لم تؤثر عليه محصلة قوى. اجعل الاحتكاك صفرًا ولاحظ.');
      } else {
        S.slider('m1', 'كتلة الأول', 20, 100, 5, 40, 'كجم', { d: 0 }); S.slider('m2', 'كتلة الثاني', 20, 100, 5, pre.m2 ? 80 : 40, 'كجم', { d: 0 }); S.slider('F', 'قوة الدفع المتبادلة', 20, 200, 10, 100, 'N', { d: 0 });
        rd.a1 = S.read('تسارع الأول', 'م/ث²'); rd.a2 = S.read('تسارع الثاني', 'م/ث²'); rd.v1 = S.read('سرعة الأول بعد الدفع', 'م/ث'); rd.v2 = S.read('سرعة الثاني بعد الدفع', 'م/ث');
        S.note('لكل فعل رد فعل مساوٍ له في المقدار ومعاكس له في الاتجاه، لكنه يؤثر على جسم آخر؛ ولذلك تختلف التسارعات إذا اختلفت الكتل.');
      }
    },
    reset(S) { c = { x: 0, v: S.p.v0 || 0 }; },
    onParam(S, k) { S.reset(); },
    step(S, dt) {
      if (mode === 'first') {
        const f = S.p.mu * S.p.m1 * g; let F = S.p.F;
        if (c.v > 1e-9) c.v += (F - f) / S.p.m1 * dt; else if (F > f) c.v += (F - f) / S.p.m1 * dt; else c.v = 0;
        if (c.v < 0) c.v = 0; c.x += c.v * dt;
      }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const t = S.t;
      const cart = (x, y, w, h, col, lab) => { rrect(ctx, x - w / 2, y - h, w, h - 8, 8, col); ctx.fillStyle = '#0a1226'; [-w / 3, w / 3].forEach(d => { ctx.beginPath(); ctx.arc(x + d, y - 4, 8, 0, TAU); ctx.fill(); ctx.strokeStyle = '#9fb7e0'; ctx.lineWidth = 2; ctx.stroke(); }); text(ctx, lab, x, y - h / 2 - 4, { color: '#06101f', weight: 700, size: 12 }); };
      if (mode === 'second' || mode === 'define') {
        const lanes = mode === 'define' ? 1 : 2, lanes_h = H / (lanes + .2);
        for (let i = 0; i < lanes; i++) {
          const m = S.p['m' + (i + 1)], F = S.p['F' + (i + 1)], a = F / m, x = .5 * a * t * t, v = a * t, y = 90 + i * lanes_h * 1.0 + (lanes === 1 ? 60 : 0);
          const L = W - 140, scale = mode === 'define' ? L / 50 : L / 40; const xx = 70 + Math.min(x * scale, L);
          ctx.fillStyle = '#1b2f55'; ctx.fillRect(40, y + 2, W - 80, 6);
          for (let k = 0; k <= 10; k++) { ctx.fillStyle = COL.dim; ctx.fillRect(70 + L * k / 10, y + 8, 2, 8); text(ctx, fmt((mode === 'define' ? 50 : 40) * k / 10, 0), 70 + L * k / 10, y + 24, { size: 9, color: COL.dim }); }
          const w = 50 + Math.sqrt(m) * (mode === 'define' ? 14 : 3);
          cart(xx, y, w, 40 + Math.sqrt(m) * (mode === 'define' ? 6 : 1), i ? COL.b : COL.a, m + ' كجم');
          arrow(ctx, xx - w / 2 - 50, y - 25, xx - w / 2 - 6, y - 25, COL.d, 3 + Math.min(F / 40, 5)); text(ctx, F + ' N', xx - w / 2 - 28, y - 40, { size: 11, color: COL.d });
          rd['a' + (i + 1)](a); text(ctx, 'v = ' + fmt(v, 2) + ' م/ث   x = ' + fmt(x, 1) + ' م', W / 2, y - 62, { size: 12, color: COL.dim });
          if (xx >= 70 + L) S.setRun(false);
        }
      } else if (mode === 'first') {
        const y = H * .62, m = S.p.m1, f = S.p.mu * m * 9.8, F = S.p.F, off = (c.x * 40) % 80;
        ctx.fillStyle = '#1b2f55'; ctx.fillRect(0, y, W, 30); for (let x = -off; x < W; x += 80) { ctx.fillStyle = '#31496e'; ctx.fillRect(x, y, 3, 30); }
        text(ctx, 'الأرضية تتحرك بصريًا لتُظهر سرعة العربة', W / 2, y + 48, { size: 11, color: COL.dim });
        const cx = W * .5, ww = 60 + m * 4; cart(cx, y, ww, 50 + m * 2, COL.a, m + ' كجم');
        if (F > 0) { arrow(ctx, cx - ww / 2 - 70, y - 30, cx - ww / 2 - 6, y - 30, COL.c, 3 + F / 10); text(ctx, 'F = ' + fmt(F, 1) + ' N', cx - ww / 2 - 40, y - 48, { size: 11, color: COL.c }); }
        if (f > 0) { arrow(ctx, cx + ww / 2 + 70, y - 14, cx + ww / 2 + 6, y - 14, COL.d, 3 + f / 10); text(ctx, 'احتكاك ' + fmt(f, 1) + ' N', cx + ww / 2 + 40, y - 32, { size: 11, color: COL.d }); }
        if (c.v > 0 || F > 0) arrow(ctx, cx, y - 78, cx - c.v * 14, y - 78, COL.b, 3); text(ctx, 'v', cx - c.v * 14 - 10, y - 78, { color: COL.b });
        rd.fnet(c.v > 1e-9 || F > f ? F - f : 0); rd.v(c.v); rd.x(c.x);
        if (c.v <= 0 && S.t > 0 && F <= f && S.p.v0 > 0) { text(ctx, 'توقفت العربة بسبب الاحتكاك', W / 2, 40, { size: 14, color: COL.d, weight: 700 }); }
        if (Math.abs((c.v > 1e-9 ? F - f : 0)) < 1e-6 && c.v > 0) text(ctx, 'المحصلة = صفر ← سرعة ثابتة', W / 2, 40, { size: 14, color: COL.c, weight: 700 });
      } else {
        const y = H * .55, m1 = S.p.m1, m2 = S.p.m2, F = S.p.F, tp = .4, a1 = F / m1, a2 = F / m2, tt = Math.min(t, tp);
        const v1 = a1 * tt, v2 = a2 * tt, x1 = t < tp ? .5 * a1 * t * t : .5 * a1 * tp * tp + v1 * (t - tp), x2 = t < tp ? .5 * a2 * t * t : .5 * a2 * tp * tp + v2 * (t - tp);
        ctx.fillStyle = '#16345f'; ctx.fillRect(0, y, W, 40); text(ctx, 'سطح جليدي بلا احتكاك', W / 2, y + 22, { size: 11, color: COL.dim });
        const sc = 30, c1 = W / 2 - 40 - x1 * sc, c2 = W / 2 + 40 + x2 * sc; const w1 = 40 + m1 * .5, w2 = 40 + m2 * .5;
        cart(c1, y, w1, 50 + m1 * .4, COL.a, m1 + ' كجم'); cart(c2, y, w2, 50 + m2 * .4, COL.b, m2 + ' كجم');
        if (t < tp) { arrow(ctx, c1 + w1 / 2 + 4, y - 40, c1 + w1 / 2 - 40, y - 40, COL.d, 4); arrow(ctx, c2 - w2 / 2 - 4, y - 40, c2 - w2 / 2 + 40, y - 40, COL.c, 4); text(ctx, 'F = ' + F + ' N', W / 2, y - 80, { color: COL.dim }); }
        else { arrow(ctx, c1, y - 85, c1 - v1 * 8, y - 85, COL.a, 3); arrow(ctx, c2, y - 85, c2 + v2 * 8, y - 85, COL.b, 3); }
        rd.a1(a1); rd.a2(a2); rd.v1(v1); rd.v2(v2); if (t > 6) S.setRun(false);
      }
    }
  });
};

SIMS.friction = (root, pre) => {
  const g = 9.8, flat = pre.mode === 'flat'; let st = { x: 0, v: 0, th: 0 }, rd = {}, sl = {};
  const SURF = { wood: ['خشب على خشب', .5, .3], rubber: ['مطاط على إسمنت', .9, .7], steel: ['فولاذ على فولاذ', .74, .57], ice: ['جليد على جليد', .1, .03] };
  return Sim(root, {
    h: 420, hm: 560, auto: false,
    init(S) {
      S.select('surf', 'السطحان', Object.entries(SURF).map(([k, v]) => [k, v[0]]), 'wood');
      S.slider('m', 'كتلة الجسم', 1, 20, 1, 5, 'كجم', { d: 0 });
      if (flat) S.slider('F', 'القوة المؤثرة F', 0, 150, 1, 20, 'N', { d: 0 }); else S.slider('th', 'زاوية السطح المائل', 0, 60, 1, 20, '°', { d: 0, reset: true });
      sl.us = S.slider('us', 'معامل الاحتكاك السكوني μs', .05, 1, .01, .5, '', { d: 2 }); sl.uk = S.slider('uk', 'معامل الاحتكاك الحركي μk', .02, 1, .01, .3, '', { d: 2 });
      rd.N = S.read('القوة العمودية N', 'N'); rd.f = S.read('قوة الاحتكاك f', 'N', 'hi'); rd.a = S.read('التسارع', 'م/ث²'); rd.state = S.read('الحالة', '');
      S.note(flat ? 'الاحتكاك السكوني يساوي القوة المؤثرة حتى يبلغ حدّه الأقصى μs·N، ثم يقل إلى μk·N عند بدء الحركة. شاهد المنحنى.' : 'على السطح المائل: N = mg cos θ ، والمركبة المحركة = mg sin θ. ينزلق الجسم عندما tan θ > μs.');
      S.press = true;
    },
    reset(S) { st = { x: 0, v: 0 }; },
    onParam(S, k) { if (k === 'surf') { const s = SURF[S.p.surf]; sl.us.set(s[1]); sl.uk.set(s[2]); } if (k === 'uk' && S.p.uk > S.p.us) sl.uk.set(S.p.us); if (k === 'us' && S.p.uk > S.p.us) sl.uk.set(S.p.us); },
    step(S, dt) {
      const m = S.p.m; let N, drive;
      if (flat) { N = m * g; drive = S.p.F; } else { const th = S.p.th * D2R; N = m * g * Math.cos(th); drive = m * g * Math.sin(th); }
      if (st.v === 0 && Math.abs(drive) <= S.p.us * N) { st.f = drive; st.a = 0; }
      else { const dir = st.v === 0 ? Math.sign(drive) : Math.sign(st.v); st.f = S.p.uk * N * dir; st.a = (drive - st.f) / m; const nv = st.v + st.a * dt; if (st.v !== 0 && Math.sign(nv) !== Math.sign(st.v) && drive <= S.p.uk * N) { st.v = 0; st.a = 0; } else st.v = nv; st.x += st.v * dt; }
      if (!flat && st.x > 5) { st.x = 5; st.v = 0; S.setRun(false); }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const m = S.p.m;
      const wide = W >= 640, sw = wide ? W * .56 : W, sh = wide ? H : H * .58;
      let N, drive; if (flat) { N = m * g; drive = S.p.F; } else { const th = S.p.th * D2R; N = m * g * Math.cos(th); drive = m * g * Math.sin(th); }
      const at = st.v === 0 && Math.abs(drive) <= S.p.us * N; const f = at ? drive : S.p.uk * N, a = at ? 0 : (drive - S.p.uk * N * Math.sign(st.v || drive)) / m;
      const bw = 50 + m * 1.5;
      if (flat) {
        const y = sh * .62, off = (st.x * 30); ctx.fillStyle = '#26364f'; ctx.fillRect(0, y, sw, 40); for (let x = -(off % 60); x < sw; x += 60) { ctx.fillStyle = '#35507a'; ctx.fillRect(x, y, 3, 40); }
        const cx = sw / 2; rrect(ctx, cx - bw / 2, y - bw, bw, bw, 6, COL.a); text(ctx, m + ' كجم', cx, y - bw / 2, { color: '#06101f', weight: 700 });
        arrow(ctx, cx - bw / 2 - 4, y - bw / 2, cx - bw / 2 - 4 - S.p.F * .8, y - bw / 2, COL.c, 4); text(ctx, 'F=' + S.p.F, cx - bw / 2 - 4 - S.p.F * .4, y - bw / 2 - 16, { color: COL.c, size: 12 });
        arrow(ctx, cx + bw / 2 + 4, y - 6, cx + bw / 2 + 4 + f * .8, y - 6, COL.d, 4); text(ctx, 'f=' + fmt(f, 1), cx + bw / 2 + f * .4, y - 22, { color: COL.d, size: 12 });
        arrow(ctx, cx, y - bw - 4, cx, y - bw - 4 - 45, COL.b, 3); text(ctx, 'N', cx + 14, y - bw - 40, { color: COL.b }); arrow(ctx, cx, y, cx, y + 45, COL.e, 3);
      } else {
        const th = S.p.th * D2R, bx = sw * .12, by = sh * .85, len = sw * .76; const ex = bx + len * Math.cos(th), ey = by - len * Math.sin(th);
        ctx.fillStyle = '#26364f'; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(ex, ey); ctx.lineTo(ex, by); ctx.closePath(); ctx.fill();
        const s = Math.min(1, (len * .08 + st.x * 40) / len), px = ex - (ex - bx) * (1 - s) * 1 - (1 - s) * 0, py = ey + (by - ey) * (1 - s);
        const u = { x: Math.cos(th), y: -Math.sin(th) }, nrm = { x: -Math.sin(th), y: -Math.cos(th) }; const p0 = { x: bx + (len * (.25 + st.x * .1)) * u.x * 1, y: by + (len * (.25 + st.x * .1)) * u.y };
        const c0 = { x: p0.x + nrm.x * bw / 2, y: p0.y + nrm.y * bw / 2 };
        ctx.save(); ctx.translate(p0.x, p0.y); ctx.rotate(-th); rrect(ctx, -bw / 2, -bw, bw, bw, 5, COL.a); ctx.restore();
        arrow(ctx, c0.x, c0.y, c0.x, c0.y + m * g * 1.1, COL.e, 3); arrow(ctx, c0.x, c0.y, c0.x + nrm.x * N * 1.1, c0.y + nrm.y * N * 1.1, COL.b, 3);
        arrow(ctx, c0.x, c0.y, c0.x - u.x * f * 1.4, c0.y - u.y * f * 1.4, COL.d, 3); text(ctx, 'N', c0.x + nrm.x * N * 1.1 - 12, c0.y + nrm.y * N * 1.1 - 8, { color: COL.b }); text(ctx, 'W', c0.x + 14, c0.y + m * g * 1.1, { color: COL.e }); text(ctx, 'f', c0.x - u.x * f * 1.4 - 10, c0.y - u.y * f * 1.4, { color: COL.d });
        text(ctx, S.p.th + '°', bx + 60, by - 10, { color: COL.dim });
        if (S.t === 0 && !S.running) st.x = Math.max(st.x, 0);
      }
      rd.N(N); rd.f(f); rd.a(a); rd.state(at ? 'ساكن (احتكاك سكوني)' : 'يتحرك (احتكاك حركي)');
      if (flat) {
        const gx = wide ? sw : 0, gy = wide ? 0 : sh, gw = wide ? W - sw : W, gh = wide ? H : H - sh;
        const gr = new Graph(); const pk = S.p.us * N, kk = S.p.uk * N, xm = 150; gr.s[0] = [[0, 0], [pk, pk], [pk + .001, kk], [xm, kk]];
        const o = gr.draw(ctx, gx + 8, gy + 8, gw - 16, gh - 16, { x0: 0, x1: xm, y0: 0, y1: Math.max(60, pk * 1.2), title: 'قوة الاحتكاك f — القوة المؤثرة F' });
        ctx.fillStyle = COL.d; ctx.beginPath(); ctx.arc(o.sx(S.p.F), o.sy(f), 6, 0, TAU); ctx.fill();
        text(ctx, 'الحد الأقصى μs·N', o.sx(pk), o.sy(pk) - 14, { size: 10, color: COL.dim });
      }
    }
  });
};

SIMS.collision = (root, pre) => {
  let a = {}, b = {}, info = null, rd = {};
  const def = pre.mode === 'def';
  return Sim(root, {
    h: def ? 340 : 400, hm: def ? 400 : 480,
    init(S) {
      S.slider('m1', 'كتلة الأولى m₁', 1, 10, .5, pre.m1 || 2, 'كجم', { d: 1, reset: true }); S.slider('v1', 'سرعة الأولى v₁', -8, 10, .5, pre.v1 ?? 4, 'م/ث', { d: 1, reset: true });
      S.slider('m2', 'كتلة الثانية m₂', 1, 10, .5, pre.m2 || 3, 'كجم', { d: 1, reset: true }); S.slider('v2', 'سرعة الثانية v₂', -8, 10, .5, pre.v2 ?? 0, 'م/ث', { d: 1, reset: true });
      if (!def) { S.slider('e', 'معامل الارتداد e', 0, 1, .05, pre.e, '', { d: 2 }); }
      if (def) { rd.p1 = S.read('كمية حركة الأولى p₁ = m·v', 'كجم·م/ث'); rd.p2 = S.read('كمية حركة الثانية p₂ = m·v', 'كجم·م/ث'); S.note('كمية الحركة p = الكتلة × السرعة، وهي كمية متجهة. تتضاعف عند مضاعفة الكتلة أو السرعة.'); }
      else {
        rd.kind = S.read('نوع التصادم', ''); rd.pb = S.read('p الكلية قبل', 'كجم·م/ث'); rd.pa = S.read('p الكلية بعد', 'كجم·م/ث', 'hi'); rd.kb = S.read('الطاقة الحركية قبل', 'جول'); rd.ka = S.read('الطاقة الحركية بعد', 'جول');
        S.note('تُحفظ كمية الحركة الكلية في جميع أنواع التصادم، أما الطاقة الحركية فتُحفظ في التصادم المرن فقط.');
      }
    },
    reset(S) { a = { x: 3, v: S.p.v1, m: S.p.m1 }; b = { x: 14, v: S.p.v2, m: S.p.m2 }; info = null; if (def) { b.x = 3; } },
    onParam(S, k) { if (!def && k === 'e') S.reset(); },
    step(S, dt) {
      a.x += a.v * dt; b.x += b.v * dt;
      if (!def && !info && a.x + .9 >= b.x - .9 && a.v > b.v) {
        const e = S.p.e, m1 = a.m, m2 = b.m, u1 = a.v, u2 = b.v;
        info = { pb: m1 * u1 + m2 * u2, kb: .5 * m1 * u1 * u1 + .5 * m2 * u2 * u2 };
        a.v = ((m1 - e * m2) * u1 + (1 + e) * m2 * u2) / (m1 + m2); b.v = ((m2 - e * m1) * u2 + (1 + e) * m1 * u1) / (m1 + m2);
        info.pa = m1 * a.v + m2 * b.v; info.ka = .5 * m1 * a.v * a.v + .5 * m2 * b.v * b.v; const ov = (a.x + .9) - (b.x - .9); a.x -= ov / 2; b.x += ov / 2;
      }
      if ((a.x < -3 || a.x > 24) && (b.x < -3 || b.x > 24) || S.t > 14) S.setRun(false);
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const sc = (W - 60) / 20, X = x => 30 + x * sc;
      const y = def ? 90 : H * .36;
      const cart = (x, yy, m, col, lab, v) => { const w = 30 + m * 4; rrect(ctx, X(x) - w / 2, yy - 30 - m, w, 30 + m, 6, col); ctx.fillStyle = '#0a1226'; [-w / 3, w / 3].forEach(d => { ctx.beginPath(); ctx.arc(X(x) + d, yy - 4, 7, 0, TAU); ctx.fill(); }); text(ctx, fmt(m, 1) + ' كجم', X(x), yy - 20 - m / 2, { color: '#06101f', weight: 700, size: 11 }); if (v) arrow(ctx, X(x), yy - 50 - m, X(x) + v * 10, yy - 50 - m, '#fff', 2.5); };
      if (def) {
        [[a, S.p.m1, S.p.v1, COL.a, 100, 'p1'], [b, S.p.m2, S.p.v2, COL.b, 220, 'p2']].forEach(([o, m, v, col, yy, k]) => {
          const xx = ((o === a ? 3 : 3) + v * S.t); ctx.fillStyle = '#16345f'; ctx.fillRect(0, yy, W, 6); const px = ((xx % 24) + 24) % 24 - 2;
          cart(px, yy, m, col, '', v); const p = m * v; rd[k](p); const bw = Math.min(W - 160, Math.abs(p) * 6); ctx.fillStyle = col; ctx.fillRect(W / 2 + (p < 0 ? -bw : 0), yy + 22, bw, 12); text(ctx, 'p = ' + fmt(m, 1) + ' × ' + fmt(v, 1) + ' = ' + fmt(p, 1), W / 2, yy + 52, { size: 12, color: col });
        });
        return;
      }
      ctx.fillStyle = '#16345f'; ctx.fillRect(0, y, W, 6);
      cart(a.x, y, a.m, COL.a, '', a.v); cart(b.x, y, b.m, COL.b, '', b.v);
      const e = S.p.e; rd.kind(e >= .999 ? 'مرن تمامًا' : e <= .001 ? 'عديم المرونة (يلتحمان)' : 'شبه مرن');
      const pb = S.p.m1 * S.p.v1 + S.p.m2 * S.p.v2, kb = .5 * S.p.m1 * S.p.v1 ** 2 + .5 * S.p.m2 * S.p.v2 ** 2;
      rd.pb(info ? info.pb : pb); rd.kb(info ? info.kb : kb, 1); rd.pa(info ? info.pa : '—'); rd.ka(info ? info.ka : '—', 1);
      const bx = 40, by = H - 28, bwid = (W - 80) / 2, mx = Math.max(30, Math.abs(pb) * 1.2, Math.abs(S.p.m1 * S.p.v1) * 1.2, Math.abs(S.p.m2 * S.p.v2) * 1.2);
      const bars = (arr, x0, lab) => { text(ctx, lab, x0 + bwid / 2, by - 112, { weight: 700, size: 13 }); arr.forEach(([v, col, n], i) => { const bh = v / mx * 70, bxx = x0 + 10 + i * (bwid / 3); ctx.fillStyle = col; ctx.fillRect(bxx + 10, bh >= 0 ? by - 50 - bh : by - 50, bwid / 3 - 24, Math.abs(bh)); text(ctx, n + ' ' + fmt(v, 1), bxx + bwid / 6 - 2, by + 2, { size: 11, color: COL.dim }); }); ctx.strokeStyle = COL.dim; ctx.beginPath(); ctx.moveTo(x0, by - 50); ctx.lineTo(x0 + bwid, by - 50); ctx.stroke(); };
      bars([[S.p.m1 * S.p.v1, COL.a, 'p₁'], [S.p.m2 * S.p.v2, COL.b, 'p₂'], [pb, COL.c, 'الكلية']], bwid + 40, 'قبل التصادم');
      bars(info ? [[a.m * a.v, COL.a, 'p₁'], [b.m * b.v, COL.b, 'p₂'], [info.pa, COL.c, 'الكلية']] : [[0, COL.a, 'p₁'], [0, COL.b, 'p₂'], [0, COL.c, 'الكلية']], 40, 'بعد التصادم');
    }
  });
};
