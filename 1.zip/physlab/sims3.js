/* ===== محاكاة 3: الموائع، البصريات، الكهرباء ===== */

SIMS.buoyancy = (root) => {
  const g = 9.81, LIQ = { water: ['ماء', 1000, '#2b7de9'], salt: ['ماء مالح', 1025, '#2a6fb8'], oil: ['زيت', 920, '#d9a21b'], alc: ['كحول', 790, '#7fb6e6'], hg: ['زئبق', 13600, '#9aa6b5'] };
  let rd = {}, pos = 0, vel = 0;
  return Sim(root, {
    h: 460, hm: 500, auto: true,
    init(S) {
      S.select('liq', 'السائل', Object.entries(LIQ).map(([k, v]) => [k, v[0] + ' (' + v[1] + ' كجم/م³)']), 'water');
      S.slider('m', 'كتلة الجسم', 50, 2000, 10, 500, 'جم', { d: 0 }); S.slider('V', 'حجم الجسم', 100, 1000, 10, 400, 'سم³', { d: 0 });
      S.check('free', 'حرّر الجسم (يطفو أو يغوص بحرية)', false); S.slider('hand', 'تحريك الجسم يدويًا (من الأعلى إلى الأسفل)', 0, 1, .01, .3, '', { d: 2 });
      rd.rho = S.read('كثافة الجسم', 'كجم/م³'); rd.W = S.read('وزن الجسم في الهواء', 'N'); rd.Fb = S.read('قوة الطفو F = ρ·g·V المغمور', 'N', 'hi'); rd.app = S.read('الوزن الظاهري في السائل', 'N'); rd.frac = S.read('نسبة الجزء المغمور', '%');
      S.note('قوة الطفو = وزن السائل المزاح. يطفو الجسم إذا كانت كثافته أقل من كثافة السائل، وتكون نسبة المغمور = ρ الجسم ÷ ρ السائل.');
    },
    reset(S) { pos = S.p.hand; vel = 0; }, onParam(S, k) { if (k === 'hand') pos = S.p.hand; },
    step(S, dt) {
      if (!S.p.free) { pos += (S.p.hand - pos) * Math.min(1, dt * 8); return; }
      const rl = LIQ[S.p.liq][1], rho = S.p.m / S.p.V * 1000, V = S.p.V * 1e-6, side = Math.cbrt(S.p.V) / 100, f = S.frac ?? 0;
      const a = ((rl * f * V * g) - rho * V * g) / (rho * V) - vel * 4; vel += a * dt; pos = clamp(pos + vel * dt * 1.2, 0, 1);
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const L = LIQ[S.p.liq], rl = L[1], V = S.p.V * 1e-6, rho = S.p.m / S.p.V * 1000;
      const tx = W * .12, tw = W * .5, ty = H * .3, th = H * .62, side = clamp(Math.cbrt(S.p.V) * 7, 40, 90), area = tw / 120;
      const lvl0 = ty + th * .35; // سطح السائل الابتدائي
      // موضع الجسم: pos 0 = أعلى (في الهواء) ، 1 = الأسفل
      const topY = ty - 90 + pos * (ty + th - side - (ty - 90)); const bottomY = topY + side;
      let f = clamp((bottomY - lvl0) / side, 0, 1); S.frac = f; const lvl = lvl0 - (f * side * side * side / 1e4) * .06 * (tw / 100);
      f = clamp((bottomY - lvl) / side, 0, 1); S.frac = f;
      ctx.fillStyle = L[2] + 'cc'; ctx.fillRect(tx, lvl, tw, ty + th - lvl); ctx.strokeStyle = '#cfe3ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(tx, ty + th); ctx.lineTo(tx + tw, ty + th); ctx.lineTo(tx + tw, ty); ctx.stroke();
      const bx = tx + tw / 2 - side / 2; ctx.strokeStyle = '#dbe7ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(bx + side / 2, 10); ctx.lineTo(bx + side / 2, topY); ctx.stroke();
      rrect(ctx, bx, topY, side, side, 4, rho > 1000 ? '#a8754b' : '#cfa86a'); text(ctx, fmt(S.p.m, 0) + ' جم', bx + side / 2, topY + side / 2, { color: '#06101f', weight: 700, size: 12 });
      const W_ = S.p.m / 1000 * g, Fb = rl * g * V * f; rd.rho(rho, 0); rd.W(W_); rd.Fb(Fb); rd.frac(f * 100, 0);
      const floating = S.p.free && rho < rl && f < .999, app = floating ? 0 : Math.max(0, W_ - Fb); rd.app(app);
      const px = tx + tw + 50; arrow(ctx, px, ty + 60, px, ty + 60 + W_ * 14, COL.d, 4); text(ctx, 'الوزن ' + fmt(W_, 2) + ' N', px, ty + 44, { color: COL.d, size: 12 });
      arrow(ctx, px + 100, ty + 60 + Fb * 14, px + 100, ty + 60, COL.b, 4); text(ctx, 'الطفو ' + fmt(Fb, 2) + ' N', px + 100, ty + 44, { color: COL.b, size: 12 });
      text(ctx, rho < rl ? 'كثافة الجسم أقل ← يطفو' : 'كثافة الجسم أكبر ← يغوص', px + 50, ty + 210, { size: 13, weight: 700, color: rho < rl ? COL.c : COL.d });
    }
  });
};

SIMS.stokes = (root) => {
  const g = 9.81, FL = { gly: ['جلسرين', 1.4, 1260], honey: ['عسل', 10, 1420], oil: ['زيت محرك', .25, 880], olive: ['زيت زيتون', .08, 910] };
  let st = { y: 0, v: 0 }, rd = {}, gr = new Graph();
  const par = S => { const f = FL[S.p.fl], r = S.p.r / 1000, rs = S.p.rho, V = 4 / 3 * Math.PI * r ** 3, eta = f[1], vt = 2 * r * r * (rs - f[2]) * g / (9 * eta), m = rs * V, tau = m / (6 * Math.PI * eta * r); return { r, rs, V, eta, rf: f[2], vt, tau, m }; };
  return Sim(root, {
    h: 440, hm: 560,
    init(S) {
      S.select('fl', 'السائل', Object.entries(FL).map(([k, v]) => [k, v[0] + ' (η = ' + v[1] + ' Pa·s)']), 'gly'); S.slider('r', 'نصف قطر الكرة', .5, 5, .5, 2, 'مم', { d: 1, reset: true }); S.slider('rho', 'كثافة مادة الكرة', 1500, 11000, 100, 7800, 'كجم/م³', { d: 0, reset: true });
      rd.vt = S.read('السرعة الحدية v = 2r²(ρ−ρf)g / 9η', 'م/ث', 'hi'); rd.v = S.read('السرعة الحالية', 'م/ث'); rd.re = S.read('عدد رينولدز Re', ''); rd.y = S.read('المسافة المقطوعة', 'سم');
      S.note('تتزايد سرعة الكرة حتى تتعادل قوة السحب (6πηrv) مع الوزن مطروحًا منه الطفو؛ عندها تثبت السرعة (السرعة الحدية). القانون دقيق عندما Re أقل من نحو 1.');
    },
    reset(S) { st = { y: 0, v: 0 }; gr.clear(); }, onParam(S, k) { if (k === 'fl') S.reset(); },
    step(S, dt) {
      const p = par(S); if (p.vt <= 0) { return; } const e = Math.exp(-dt / p.tau); const nv = p.vt + (st.v - p.vt) * e; st.y += p.vt * dt + (st.v - p.vt) * p.tau * (1 - e); st.v = nv; gr.add(0, S.t, st.v); if (st.y >= .4) { st.y = .4; S.setRun(false); }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const p = par(S), wide = W >= 640, sw = wide ? W * .38 : W, sh = wide ? H : H * .55, tx = sw / 2 - 40, ty = 40, th = sh - 70;
      const col = { gly: '#9bd1c0', honey: '#d99a1f', oil: '#7a5a2a', olive: '#a8b23a' }[S.p.fl]; ctx.fillStyle = col + '88'; ctx.fillRect(tx, ty + 20, 80, th - 20); ctx.strokeStyle = '#cfe3ff'; ctx.lineWidth = 3; ctx.strokeRect(tx, ty, 80, th);
      const y = ty + 20 + (st.y / .4) * (th - 50), rr = 4 + S.p.r * 1.4; ctx.fillStyle = '#c9ced6'; ctx.beginPath(); ctx.arc(tx + 40, y, rr, 0, TAU); ctx.fill();
      const Fw = (p.rs - p.rf) * p.V * g, Fd = 6 * Math.PI * p.eta * p.r * st.v, k = 40 / Math.max(Fw, 1e-9); arrow(ctx, tx + 40 + rr + 14, y, tx + 40 + rr + 14, y + 40, COL.d, 3); arrow(ctx, tx + 40 - rr - 14, y, tx + 40 - rr - 14, y - Math.min(40, 40 * Fd / Fw || 0), COL.b, 3);
      text(ctx, 'الوزن−الطفو', tx + 40 + rr + 50, y + 20, { size: 11, color: COL.d }); text(ctx, 'السحب', tx + 40 - rr - 34, y - 10, { size: 11, color: COL.b });
      const Re = p.rf * st.v * 2 * p.r / p.eta; rd.vt(p.vt); rd.v(st.v); rd.re(p.rf * p.vt * 2 * p.r / p.eta, 2); rd.y(st.y * 100, 1);
      if (p.vt <= 0) text(ctx, 'الكرة أخف من السائل فتطفو!', sw / 2, H * .5, { color: COL.d, weight: 700 });
      const gx = wide ? sw : 0, gy = wide ? 0 : sh, gw = wide ? W - sw : W, gh = wide ? H : H - sh;
      const Tm = Math.max(1, 0.4 / Math.max(p.vt, 1e-6) * 1.1); const o = gr.draw(ctx, gx + 8, gy + 8, gw - 16, gh - 16, { x0: 0, x1: Math.min(30, Tm), y0: 0, y1: Math.max(p.vt * 1.2, 1e-4), title: 'السرعة (م/ث) — الزمن (ث)' });
      ctx.setLineDash([5, 5]); ctx.strokeStyle = COL.d; ctx.beginPath(); ctx.moveTo(o.sx(0), o.sy(p.vt)); ctx.lineTo(o.sx(Math.min(30, Tm)), o.sy(p.vt)); ctx.stroke(); ctx.setLineDash([]); text(ctx, 'v الحدية', o.sx(Math.min(30, Tm)) - 36, o.sy(p.vt) - 10, { size: 11, color: COL.d });
    }
  });
};

SIMS.lens = (root) => {
  let rd = {}, sl = {};
  return Sim(root, {
    h: 400, hm: 420, static: true,
    init(S) {
      S.select('type', 'نوع العدسة', [['1', 'محدبة (لامّة)'], ['-1', 'مقعرة (مفرّقة)']], '1'); S.noResetOnSelect = true;
      sl.f = S.slider('f', 'البعد البؤري |f|', 5, 20, 1, 10, 'سم', { d: 0 }); sl.u = S.slider('u', 'بُعد الجسم عن العدسة u (يمكن سحب الجسم)', 4, 45, .5, 25, 'سم', { d: 1 });
      rd.v = S.read('بعد الصورة v', 'سم'); rd.m = S.read('التكبير m = −v/u', '×'); rd.nat = S.read('طبيعة الصورة', '', 'hi');
      S.note('معادلة العدسة الرقيقة: 1/f = 1/v + 1/u (الجسم الحقيقي u موجب، العدسة المحدبة f موجبة والمقعرة f سالبة). الصورة الحقيقية تظهر على الشاشة وتكون مقلوبة.');
    },
    down(S) { const L = this.geo(S); if (Math.abs(S.ptr.x - L.xo) < 30 && S.ptr.y > L.axisY - 100 && S.ptr.y < L.axisY + 20) S.drag = true; },
    move(S) { if (S.drag) { const L = this.geo(S); sl.u.set(clamp(Math.round((L.xl - S.ptr.x) / L.sc * 2) / 2, 4, 45)); } },
    geo(S) { const sc = (S.W - 40) / 110, xl = 20 + 50 * sc; return { sc, xl, xo: xl - S.p.u * sc, axisY: S.H / 2 + 20 }; },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const L = this.geo(S), sc = L.sc, xl = L.xl, ay = L.axisY, sgn = +S.p.type, f = sgn * S.p.f, u = S.p.u, ho = 40;
      let uu = u; if (Math.abs(1 / f - 1 / uu) < 1e-4) uu += .01; const v = 1 / (1 / f - 1 / uu), m = -v / uu, hi = m * ho;
      ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(10, ay); ctx.lineTo(W - 10, ay); ctx.stroke();
      ctx.strokeStyle = '#7dd3fc'; ctx.fillStyle = 'rgba(125,211,252,.18)'; ctx.lineWidth = 2; ctx.beginPath(); if (sgn > 0) { ctx.ellipse(xl, ay, 14, 120, 0, 0, TAU); } else { ctx.moveTo(xl - 18, ay - 120); ctx.quadraticCurveTo(xl - 2, ay, xl - 18, ay + 120); ctx.lineTo(xl + 18, ay + 120); ctx.quadraticCurveTo(xl + 2, ay, xl + 18, ay - 120); ctx.closePath(); } ctx.fill(); ctx.stroke();
      [-1, 1].forEach(s => { ctx.fillStyle = COL.a; ctx.beginPath(); ctx.arc(xl + s * Math.abs(f) * sc, ay, 4, 0, TAU); ctx.fill(); text(ctx, 'F', xl + s * Math.abs(f) * sc, ay + 16, { size: 11, color: COL.a }); });
      arrow(ctx, L.xo, ay, L.xo, ay - ho, COL.c, 4, 10); text(ctx, 'الجسم', L.xo, ay + 16, { size: 11, color: COL.c });
      const ys = h => ay - h, tipO = { x: L.xo, y: ys(ho) }, tipI = { x: xl + v * sc, y: ys(hi) };
      const rays = [ys(ho), ay, ys(hi)]; const cols = ['#ffb547', '#ff6b81', '#b392f0'];
      rays.forEach((ly, i) => {
        ctx.lineWidth = 1.8; ctx.strokeStyle = cols[i]; ctx.beginPath(); ctx.moveTo(tipO.x, tipO.y); ctx.lineTo(xl, ly); ctx.stroke();
        let dx = tipI.x - xl, dy = tipI.y - ly; if (v < 0) { dx = -dx; dy = -dy; } /* اتجاه الشعاع الخارج نحو اليمين */ if (Math.abs(dx) < 1e-6) dx = 1e-6; if (dx < 0) { dx = -dx; dy = -dy; }
        const ex = W - 10; ctx.beginPath(); ctx.moveTo(xl, ly); ctx.lineTo(ex, ly + dy / dx * (ex - xl)); ctx.stroke();
        if (v < 0) { ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(xl, ly); ctx.lineTo(tipI.x, tipI.y); ctx.stroke(); ctx.setLineDash([]); }
      });
      if (Math.abs(v) < 400) { ctx.setLineDash(v < 0 ? [4, 4] : []); arrow(ctx, tipI.x, ay, tipI.x, tipI.y, v < 0 ? COL.d + 'aa' : COL.d, 4, 10); ctx.setLineDash([]); }
      rd.v(v); rd.m(m); rd.nat(v > 0 ? 'حقيقية ' + (m < 0 ? 'مقلوبة ' : '') + (Math.abs(m) > 1 ? 'مكبّرة' : Math.abs(m) < 1 ? 'مصغّرة' : 'بنفس الحجم') : 'وهمية معتدلة ' + (Math.abs(m) > 1 ? 'مكبّرة' : 'مصغّرة'));
    }
  });
};

SIMS.prism = (root) => {
  const MAT = { crown: ['زجاج تاجي', 1.5046, .0042], flint: ['زجاج صوان (ثقيل)', 1.5875, .0100], water: ['ماء', 1.3243, .0031] };
  const LAM = [['أحمر', .700, '#ff2d2d'], ['برتقالي', .610, '#ff8c1a'], ['أصفر', .580, '#ffe81a'], ['أخضر', .530, '#28e05a'], ['أزرق', .470, '#2f8bff'], ['نيلي', .445, '#4b3bff'], ['بنفسجي', .410, '#a642ff']];
  let rd = {};
  let EX = 1; const nOf = (mat, lam) => { const f = l => MAT[mat][1] + MAT[mat][2] / (l * l); return f(.589) + (f(lam) - f(.589)) * EX; };
  const refr = (d, n, eta) => { const c = -(n.x * d.x + n.y * d.y); const k = 1 - eta * eta * (1 - c * c); if (k < 0) return null; const a = eta * c - Math.sqrt(k); return { x: eta * d.x + a * n.x, y: eta * d.y + a * n.y }; };
  const inter = (p, d, a, b) => { const ex = b.x - a.x, ey = b.y - a.y, den = d.x * ey - d.y * ex; if (Math.abs(den) < 1e-9) return null; const t = ((a.x - p.x) * ey - (a.y - p.y) * ex) / den, s = ((a.x - p.x) * d.y - (a.y - p.y) * d.x) / den; return (t > 1e-6 && s >= 0 && s <= 1) ? { t, s } : null; };
  return Sim(root, {
    h: 430, hm: 440, static: true,
    init(S) {
      S.select('mat', 'مادة المنشور', Object.entries(MAT).map(([k, v]) => [k, v[0]]), 'crown'); S.noResetOnSelect = true; S.select('src', 'لون الحزمة الساقطة', [['white', 'أبيض'], ...LAM.map((l, i) => [String(i), l[0]])], 'white');
      S.slider('i', 'زاوية السقوط على الوجه الأول', 25, 75, 1, 50, '°', { d: 0 }); S.slider('A', 'زاوية رأس المنشور', 30, 70, 1, 60, '°', { d: 0 }); S.slider('ex', 'إبراز التشتت للإيضاح (1 = القيمة الحقيقية)', 1, 6, .5, 4, '×', { d: 1 });
      rd.dr = S.read('انحراف الأحمر', '°'); rd.dv = S.read('انحراف البنفسجي', '°'); rd.sp = S.read('التشتت الزاوي (البنفسجي − الأحمر)', '°', 'hi');
      S.note('الضوء الأبيض مزيج من ألوان؛ ولكل لون معامل انكسار مختلف، فينحرف البنفسجي أكثر من الأحمر. اللون المفرد لا يتحلل لكنه ينحرف فقط. (التشتت الحقيقي صغير، لذلك نُبرزه للإيضاح؛ اجعله 1× لترى القيمة الحقيقية).');
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); EX = S.p.ex; const A = S.p.A * D2R, Ls = Math.min(W * .26, 200), cx = W * .42, cy = H * .55;
      const hb = Ls * Math.sin(A / 2), hh = Ls * Math.cos(A / 2); const apex = { x: cx, y: cy - hh * 2 / 3 }, bl = { x: cx - hb, y: cy + hh / 3 }, br = { x: cx + hb, y: cy + hh / 3 };
      ctx.fillStyle = 'rgba(125,211,252,.16)'; ctx.strokeStyle = '#9fd8ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(apex.x, apex.y); ctx.lineTo(bl.x, bl.y); ctx.lineTo(br.x, br.y); ctx.closePath(); ctx.fill(); ctx.stroke();
      const e = { x: apex.x - bl.x, y: apex.y - bl.y }, el = Math.hypot(e.x, e.y); const nOut = { x: -e.y / el, y: e.x / el }; /* تأكد أنه للخارج */ const mid = { x: (apex.x + bl.x) / 2, y: (apex.y + bl.y) / 2 }; if ((mid.x - cx) * nOut.x + (mid.y - cy) * nOut.y < 0) { nOut.x *= -1; nOut.y *= -1; }
      const m = { x: -nOut.x, y: -nOut.y }; const ang = Math.atan2(m.y, m.x) - S.p.i * D2R; const d0 = { x: Math.cos(ang), y: Math.sin(ang) };
      const P = { x: bl.x + e.x * .45, y: bl.y + e.y * .45 }; const Ls0 = Math.min(250, (P.x - 10) / Math.max(.2, d0.x)); const start = { x: P.x - d0.x * Ls0, y: P.y - d0.y * Ls0 };
      const scrX = W - 36; ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(scrX, 20, 10, H - 40);
      const white = S.p.src === 'white', list = white ? LAM : [LAM[+S.p.src]]; ctx.lineWidth = 3; ctx.strokeStyle = '#fff'; ctx.beginPath(); ctx.moveTo(start.x, start.y); ctx.lineTo(P.x, P.y); ctx.stroke();
      ctx.globalCompositeOperation = 'lighter'; const devs = [];
      list.forEach(([nm, lam, col]) => {
        const n = nOf(S.p.mat, lam); const d1 = refr(d0, nOut, 1 / n); if (!d1) return; ctx.strokeStyle = col; ctx.lineWidth = 2.2;
        let best = null, bestEdge = null; [[apex, br, 'R'], [bl, br, 'B'], [bl, apex, 'L']].forEach(([a, b, nm2]) => { const r = inter(P, d1, a, b); if (r && (!best || r.t < best.t)) { best = r; bestEdge = [a, b]; } });
        if (!best) return; const Q = { x: P.x + d1.x * best.t, y: P.y + d1.y * best.t }; ctx.beginPath(); ctx.moveTo(P.x, P.y); ctx.lineTo(Q.x, Q.y); ctx.stroke();
        const ex = bestEdge[1].x - bestEdge[0].x, ey = bestEdge[1].y - bestEdge[0].y, ln = Math.hypot(ex, ey); let no = { x: ey / ln, y: -ex / ln }; if (((Q.x - cx) * no.x + (Q.y - cy) * no.y) < 0) { no.x *= -1; no.y *= -1; }
        const d2 = refr(d1, { x: -no.x, y: -no.y }, n); if (!d2) { return; } if (d2.x <= 0) return;
        const tx = (scrX - Q.x) / d2.x; ctx.beginPath(); ctx.moveTo(Q.x, Q.y); ctx.lineTo(scrX, Q.y + d2.y * tx); ctx.stroke(); ctx.fillStyle = col; ctx.fillRect(scrX - 4, Q.y + d2.y * tx - 3, 12, 6);
        const dev = (Math.atan2(d2.y, d2.x) - Math.atan2(d0.y, d0.x)) / D2R; devs.push([nm, dev]);
      });
      ctx.globalCompositeOperation = 'source-over';
      const dr = devs.find(d => d[0] === 'أحمر'), dv = devs.find(d => d[0] === 'بنفسجي'); const one = devs[0];
      rd.dr(dr ? Math.abs(dr[1]) : (one ? Math.abs(one[1]) : '—'), 1); rd.dv(dv ? Math.abs(dv[1]) : '—', 1); rd.sp(dr && dv ? Math.abs(dv[1] - dr[1]) : 0, 2);
      text(ctx, 'شاشة', scrX + 5, 12, { size: 11, color: COL.dim });
    }
  });
};

SIMS.capacitor = (root, pre) => {
  const mode = pre.mode, e0 = 8.854e-12; let rd = {}, gr = new Graph();
  return Sim(root, {
    h: 430, hm: 520, static: mode !== 'rc', auto: mode === 'rc',
    init(S) {
      if (mode === 'rc') {
        S.select('op', 'العملية', [['c', 'شحن المكثف'], ['d', 'تفريغ المكثف']], 'c'); S.slider('V', 'جهد البطارية', 1, 24, 1, 12, 'V', { d: 0, reset: true }); S.slider('R', 'المقاومة', 100, 10000, 100, 2000, 'Ω', { d: 0, reset: true }); S.slider('C', 'سعة المكثف', 100, 4700, 100, 1000, 'µF', { d: 0, reset: true });
        rd.tau = S.read('ثابت الزمن τ = R·C', 'ث', 'hi'); rd.vc = S.read('جهد المكثف Vc', 'V'); rd.i = S.read('التيار I', 'mA'); rd.q = S.read('الشحنة Q = C·Vc', 'mC'); S.note('عند الشحن: Vc = V(1 − e^(−t/τ)). بعد زمن τ يبلغ جهد المكثف نحو 63% من جهد البطارية، وبعد 5τ يكتمل الشحن تقريبًا. التفريغ: Vc = V·e^(−t/τ).');
      } else if (mode === 'capacity') {
        S.slider('A', 'مساحة اللوح', 10, 200, 10, 100, 'سم²', { d: 0 }); S.slider('d', 'المسافة بين اللوحين', .5, 5, .5, 2, 'مم', { d: 1 }); S.select('k', 'المادة العازلة', [['1', 'هواء (κ = 1)'], ['2.1', 'تفلون (κ = 2.1)'], ['3.7', 'ورق (κ = 3.7)'], ['6', 'زجاج (κ = 6)'], ['80', 'ماء نقي (κ = 80)']], '1'); S.slider('V', 'فرق الجهد', 1, 12, 1, 9, 'V', { d: 0 });
        rd.C = S.read('السعة C = κ·ε₀·A / d', 'pF', 'hi'); rd.Q = S.read('الشحنة Q = C·V', 'nC'); rd.E = S.read('الطاقة المخزنة ½CV²', 'nJ'); S.note('تزداد السعة بزيادة مساحة اللوحين وبوجود عازل، وتقل بزيادة المسافة بينهما.');
      } else {
        const n = 3; for (let i = 1; i <= n; i++) S.slider('C' + i, 'السعة C' + i, 1, 20, 1, [4, 6, 12][i - 1], 'µF', { d: 0 }); S.slider('V', 'جهد المصدر', 1, 24, 1, 12, 'V', { d: 0 });
        rd.Ceq = S.read(mode === 'series' ? 'السعة المكافئة 1/C = Σ(1/Cᵢ)' : 'السعة المكافئة C = ΣCᵢ', 'µF', 'hi'); rd.Q = S.read('الشحنة الكلية', 'µC');
        S.note(mode === 'series' ? 'في التوصيل على التوالي: الشحنة متساوية على كل مكثف، والجهد يتوزع عكسيًا مع السعة، والسعة المكافئة أصغر من أصغر مكثف.' : 'في التوصيل على التوازي: الجهد متساوٍ على كل مكثف، والشحنة تتوزع طرديًا مع السعة، والسعة المكافئة تساوي المجموع.');
      }
    },
    reset(S) { gr.clear(); }, onParam(S) { },
    step(S, dt) { if (mode === 'rc') { const tau = S.p.R * S.p.C * 1e-6, t = S.t, V = S.p.V; const vc = S.p.op === 'c' ? V * (1 - Math.exp(-t / tau)) : V * Math.exp(-t / tau); gr.add(0, t, vc); gr.add(1, t, V / S.p.R * 1000 * Math.exp(-t / tau) * 1); if (t > 5 * tau) S.setRun(false); } },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const wide = W >= 640;
      if (mode === 'rc') {
        const tau = S.p.R * S.p.C * 1e-6, t = S.t, V = S.p.V, ch = S.p.op === 'c', vc = ch ? V * (1 - Math.exp(-t / tau)) : V * Math.exp(-t / tau), I = V / S.p.R * Math.exp(-t / tau) * 1000;
        const sw = wide ? W * .4 : W, sh = wide ? H : H * .45, x0 = 40, x1 = sw - 40, y0 = 60, y1 = sh - 50; ctx.strokeStyle = '#cfe3ff'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(x0, y1); ctx.lineTo(x0, y0); ctx.lineTo(x1, y0); ctx.lineTo(x1, y1); ctx.lineTo(x0, y1); ctx.stroke();
        rrect(ctx, (x0 + x1) / 2 - 36, y0 - 12, 72, 24, 4, '#0c1730', COL.a); text(ctx, 'R = ' + S.p.R + 'Ω', (x0 + x1) / 2, y0, { size: 12, color: COL.a });
        ctx.fillStyle = '#0c1730'; ctx.fillRect(x0 - 14, (y0 + y1) / 2 - 22, 28, 44); ctx.strokeStyle = '#ffd08a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x0 - 18, (y0 + y1) / 2 - 8); ctx.lineTo(x0 + 18, (y0 + y1) / 2 - 8); ctx.moveTo(x0 - 9, (y0 + y1) / 2 + 12); ctx.lineTo(x0 + 9, (y0 + y1) / 2 + 12); ctx.stroke(); text(ctx, V + ' V', x0 + 38, (y0 + y1) / 2, { size: 12, color: '#ffd08a' });
        const cy = (y0 + y1) / 2; ctx.clearRect(x1 - 30, cy - 18, 60, 36); ctx.fillStyle = '#0a1226'; ctx.fillRect(x1 - 30, cy - 18, 60, 36); ctx.fillStyle = COL.b; ctx.fillRect(x1 - 26, cy - 10, 52, 4); ctx.fillRect(x1 - 26, cy + 8, 52, 4); ctx.fillStyle = `rgba(76,201,240,${vc / V * .6})`; ctx.fillRect(x1 - 26, cy - 6, 52, 14);
        const nq = Math.round(vc / V * 6); for (let i = 0; i < nq; i++) { text(ctx, '+', x1 - 20 + i * 8, cy - 22, { size: 12, color: COL.d, weight: 700 }); text(ctx, '−', x1 - 20 + i * 8, cy + 24, { size: 12, color: COL.b, weight: 700 }); }
        text(ctx, 'C = ' + S.p.C + 'µF', x1 - 52, cy, { size: 11, color: COL.b }); text(ctx, ch ? 'الشحن: البطارية متصلة' : 'التفريغ: عبر المقاومة', sw / 2, sh - 16, { size: 12, color: COL.dim });
        rd.tau(tau, 2); rd.vc(vc); rd.i(I, 2); rd.q(vc * S.p.C * 1e-6 * 1000, 2);
        const gx = wide ? sw : 0, gy = wide ? 0 : sh, gw = wide ? W - sw : W, gh = wide ? H : H - sh, gm = new Graph(); const T = 5 * tau;
        const o = gr.draw(ctx, gx + 8, gy + 8, gw - 16, gh - 16, { x0: 0, x1: T, y0: 0, y1: V * 1.05, title: 'الأزرق: Vc (فولت) — الأحمر: I (مللي أمبير) — الزمن (ث)', colors: [COL.b, COL.d] });
        ctx.setLineDash([4, 4]); ctx.strokeStyle = COL.dim; const vtau = ch ? .632 * V : .368 * V; ctx.beginPath(); ctx.moveTo(o.sx(0), o.sy(vtau)); ctx.lineTo(o.sx(tau), o.sy(vtau)); ctx.lineTo(o.sx(tau), o.sy(0)); ctx.stroke(); ctx.setLineDash([]); text(ctx, 't = τ', o.sx(tau), o.sy(0) - 10, { size: 10, color: COL.dim });
      } else if (mode === 'capacity') {
        const k = S.p.k, A = S.p.A * 1e-4, d = S.p.d * 1e-3, C = k * e0 * A / d, Q = C * S.p.V; rd.C(C * 1e12, 1); rd.Q(Q * 1e9, 3); rd.E(.5 * C * S.p.V ** 2 * 1e9, 3);
        const cx = W / 2, cy = H / 2, pw = 60 + S.p.A * 1.4, gap = 20 + S.p.d * 22; ctx.fillStyle = k > 1 ? 'rgba(125,211,252,' + Math.min(.55, .12 + Math.log10(k) * .2) + ')' : 'rgba(0,0,0,0)'; ctx.fillRect(cx - pw / 2, cy - gap / 2, pw, gap);
        ctx.fillStyle = '#cfe3ff'; ctx.fillRect(cx - pw / 2, cy - gap / 2 - 10, pw, 10); ctx.fillRect(cx - pw / 2, cy + gap / 2, pw, 10);
        const n = Math.round(clamp(Q * 1e9 * 3, 2, 14)); for (let i = 0; i < n; i++) { const x = cx - pw / 2 + (i + .5) * pw / n; text(ctx, '+', x, cy - gap / 2 - 18, { color: COL.d, weight: 700 }); text(ctx, '−', x, cy + gap / 2 + 20, { color: COL.b, weight: 700 }); ctx.strokeStyle = 'rgba(255,181,71,.5)'; ctx.beginPath(); ctx.moveTo(x, cy - gap / 2); ctx.lineTo(x, cy + gap / 2); ctx.stroke(); }
        text(ctx, 'A = ' + S.p.A + ' سم²', cx + pw / 2 + 50, cy - gap / 2 - 5, { size: 12, color: COL.dim }); arrow(ctx, cx + pw / 2 + 14, cy - gap / 2, cx + pw / 2 + 14, cy + gap / 2, COL.c, 2); text(ctx, 'd = ' + S.p.d + ' مم', cx + pw / 2 + 52, cy, { size: 12, color: COL.c });
      } else {
        const cs = [S.p.C1, S.p.C2, S.p.C3], V = S.p.V, ser = mode === 'series'; const Ceq = ser ? 1 / cs.reduce((a, c) => a + 1 / c, 0) : cs.reduce((a, c) => a + c, 0), Qt = Ceq * V; rd.Ceq(Ceq, 2); rd.Q(Qt, 1);
        const cx = W / 2, bw = Math.min(150, (W - 100) / 3);
        cs.forEach((c, i) => {
          const x = cx + (i - 1) * (bw + 20), y = H * .38; ctx.fillStyle = '#0a1226'; rrect(ctx, x - bw / 2, y - 40, bw, 130, 8, '#0f2145', COL.grid);
          ctx.fillStyle = COL.b; ctx.fillRect(x - 36, y, 72, 5); ctx.fillRect(x - 36, y + 26, 72, 5);
          const Vi = ser ? Qt / c : V, Qi = ser ? Qt : c * V; text(ctx, 'C' + (i + 1) + ' = ' + c + ' µF', x, y - 22, { size: 12, color: COL.b, weight: 700 });
          text(ctx, 'V = ' + fmt(Vi, 2) + ' V', x, y + 52, { size: 12, color: COL.a }); text(ctx, 'Q = ' + fmt(Qi, 1) + ' µC', x, y + 72, { size: 12, color: COL.d });
          ctx.fillStyle = COL.a; ctx.fillRect(x - bw / 2 + 8, H - 80 - Vi / 24 * 100, 16, Vi / 24 * 100); ctx.fillStyle = COL.d; ctx.fillRect(x + bw / 2 - 24, H - 80 - Qi / 300 * 100, 16, Qi / 300 * 100);
        });
        text(ctx, 'عمود برتقالي: الجهد   |   عمود أحمر: الشحنة', cx, H - 52, { size: 11, color: COL.dim }); text(ctx, ser ? 'التوصيل على التوالي' : 'التوصيل على التوازي', cx, 24, { weight: 700, size: 15 });
        text(ctx, 'C مكافئة = ' + fmt(Ceq, 2) + ' µF', cx, H - 24, { weight: 700, color: COL.c });
      }
    }
  });
};

SIMS.circuit = (root, pre) => {
  const mode = pre.mode; let rd = {}, ph = 0;
  const APP = { led: ['مصباح LED', 10], tv: ['تلفاز', 100], fridge: ['ثلاجة', 150], iron: ['مكواة', 1200], kettle: ['غلاية ماء', 2000], ac: ['مكيّف', 2000], heater: ['سخان ماء', 3000] };
  return Sim(root, {
    h: 400, hm: 460, auto: mode === 'volt', static: mode !== 'volt',
    init(S) {
      if (mode === 'effects') { S.slider('V', 'الجهد', 0, 12, 1, 6, 'V', { d: 0 }); S.slider('R', 'مقاومة الدائرة', 2, 20, 1, 6, 'Ω', { d: 0 }); rd.I = S.read('التيار I = V/R', 'A'); rd.P = S.read('القدرة P = V·I', 'W', 'hi'); S.note('للتيار الكهربائي آثار: حرارية (تسخين سلك)، وضوئية (إضاءة مصباح)، ومغناطيسية (مغنطة مسمار تجذب مشابك).'); }
      else if (mode === 'volt') { S.slider('V', 'جهد البطارية', 1, 24, 1, 12, 'V', { d: 0 }); S.slider('R1', 'المقاومة R₁', 1, 20, 1, 4, 'Ω', { d: 0 }); S.slider('R2', 'المقاومة R₂', 1, 20, 1, 8, 'Ω', { d: 0 }); S.select('mt', 'موضع الفولتميتر', [['0', 'على البطارية'], ['1', 'على R₁'], ['2', 'على R₂']], '0'); S.noResetOnSelect = true; rd.I = S.read('التيار I', 'A'); rd.V = S.read('قراءة الفولتميتر', 'V', 'hi'); S.note('فرق الجهد يتوزع بين المقاومات المتصلة على التوالي حسب قيمها: V₁ + V₂ = V، والتيار واحد في الدائرة.'); }
      else { S.select('ap', 'الجهاز', Object.entries(APP).map(([k, v]) => [k, v[0] + ' (' + v[1] + ' واط)']), 'kettle'); S.noResetOnSelect = true; S.slider('h', 'ساعات التشغيل يوميًا', .5, 24, .5, 3, 'ساعة', { d: 1 }); S.slider('dd', 'عدد الأيام', 1, 30, 1, 30, 'يوم', { d: 0 }); S.slider('tr', 'تعرفة الكهرباء', .05, .5, .01, .18, 'ريال/ك.و.س', { d: 2 }); rd.E = S.read('الطاقة المستهلكة E = P × t', 'ك.و.س', 'hi'); rd.C = S.read('التكلفة التقريبية', 'ريال'); rd.I = S.read('التيار عند 220 فولت', 'A'); S.note('الطاقة بالكيلوواط·ساعة = القدرة (كيلوواط) × الزمن (ساعة). التعرفة هنا قابلة للتعديل وليست رسمية.'); }
    },
    reset(S) { ph = 0; }, onParam() { }, step(S, dt) { ph += dt; },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0);
      if (mode === 'effects') {
        const I = S.p.V / S.p.R, P = S.p.V * I; rd.I(I); rd.P(P, 1); const k = clamp(P / 24, 0, 1), w = W / 3;
        let cx = w / 2, cy = H * .42; const gl = ctx.createRadialGradient(cx, cy, 5, cx, cy, 20 + 70 * k); gl.addColorStop(0, `rgba(255,230,120,${.2 + .8 * k})`); gl.addColorStop(1, 'rgba(255,230,120,0)'); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(cx, cy, 20 + 70 * k, 0, TAU); ctx.fill(); ctx.fillStyle = `rgba(255,225,130,${.25 + .75 * k})`; ctx.strokeStyle = '#cfe3ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, 24, 0, TAU); ctx.fill(); ctx.stroke(); ctx.fillRect(cx - 10, cy + 22, 20, 20); text(ctx, 'الأثر الضوئي', cx, H - 40, { weight: 700 });
        cx = w * 1.5; ctx.strokeStyle = `rgb(${120 + 135 * k},${90 - 60 * k},${70 - 50 * k})`; ctx.lineWidth = 5 + 3 * k; ctx.beginPath(); for (let i = 0; i <= 10; i++) { const x = cx - 60 + i * 12; ctx.lineTo(x, cy + (i % 2 ? 10 : -10)); } ctx.stroke(); ctx.fillStyle = '#3a4a66'; ctx.fillRect(cx + 78, cy - 50, 14, 90); ctx.fillStyle = `rgb(${255 * k + 60},${100 + 50 * k},60)`; ctx.fillRect(cx + 78, cy + 40 - 90 * k, 14, 90 * k); text(ctx, fmt(25 + 275 * k, 0) + ' °C', cx + 85, cy - 62, { size: 11 }); text(ctx, 'الأثر الحراري', cx, H - 40, { weight: 700 });
        cx = w * 2.5; ctx.fillStyle = '#8c98ab'; ctx.fillRect(cx - 50, cy - 8, 100, 16); ctx.strokeStyle = COL.a; ctx.lineWidth = 2; for (let i = 0; i < 7; i++) { ctx.beginPath(); ctx.arc(cx - 40 + i * 13, cy, 14, 0, TAU); ctx.stroke(); } const clips = Math.round(k * 7); for (let i = 0; i < clips; i++) { ctx.fillStyle = '#cdd5df'; ctx.fillRect(cx - 30 + (i % 4) * 16, cy + 16 + Math.floor(i / 4) * 12, 12, 5); } text(ctx, 'الأثر المغناطيسي (' + clips + ' مشابك)', cx, H - 40, { weight: 700 });
      } else if (mode === 'volt') {
        const R = S.p.R1 + S.p.R2, I = S.p.V / R, V1 = I * S.p.R1, V2 = I * S.p.R2; rd.I(I); rd.V(+S.p.mt === 0 ? S.p.V : +S.p.mt === 1 ? V1 : V2);
        const x0 = 70, x1 = W - 70, y0 = 90, y1 = H - 90; ctx.strokeStyle = '#cfe3ff'; ctx.lineWidth = 2.5; ctx.strokeRect(x0, y0, x1 - x0, y1 - y0);
        const comp = (x, y, w, h, txt, col) => { ctx.fillStyle = '#0c1730'; ctx.fillRect(x - w / 2, y - h / 2, w, h); ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.strokeRect(x - w / 2, y - h / 2, w, h); text(ctx, txt, x, y, { size: 12, color: col }); };
        comp(x0, (y0 + y1) / 2, 30, 56, S.p.V + 'V', '#ffd08a'); const xa = x0 + (x1 - x0) * .3, xb = x0 + (x1 - x0) * .7; comp(xa, y0, 74, 28, 'R₁ ' + S.p.R1 + 'Ω', COL.a); comp(xb, y0, 74, 28, 'R₂ ' + S.p.R2 + 'Ω', COL.c);
        const n = 22, per = 2 * ((x1 - x0) + (y1 - y0)); for (let i = 0; i < n; i++) { let s = ((i / n + ph * (.03 + I * .01)) % 1) * per, x, y; if (s < x1 - x0) { x = x0 + s; y = y0; } else if (s < x1 - x0 + y1 - y0) { x = x1; y = y0 + s - (x1 - x0); } else if (s < 2 * (x1 - x0) + y1 - y0) { x = x1 - (s - (x1 - x0) - (y1 - y0)); y = y1; } else { x = x0; y = y1 - (s - 2 * (x1 - x0) - (y1 - y0)); } ctx.fillStyle = COL.b; ctx.beginPath(); ctx.arc(x, y, 3, 0, TAU); ctx.fill(); }
        const mt = +S.p.mt, mx = mt === 0 ? x0 + 60 : mt === 1 ? xa : xb, mval = mt === 0 ? S.p.V : mt === 1 ? V1 : V2; ctx.fillStyle = '#0a1226'; ctx.beginPath(); ctx.arc(mx, y1 + 0, 26, 0, TAU); ctx.fill(); ctx.strokeStyle = COL.d; ctx.lineWidth = 3; ctx.stroke(); text(ctx, 'V', mx, y1 - 9, { color: COL.d, weight: 700 }); text(ctx, fmt(mval, 2), mx, y1 + 8, { size: 12 });
        text(ctx, 'V₁ = ' + fmt(V1, 2) + ' V     V₂ = ' + fmt(V2, 2) + ' V     V₁ + V₂ = ' + fmt(V1 + V2, 2) + ' V', W / 2, 36, { size: 13, color: COL.dim });
      } else {
        const a = APP[S.p.ap], P = a[1], E = P / 1000 * S.p.h * S.p.dd, cost = E * S.p.tr; rd.E(E, 2); rd.C(cost, 2); rd.I(P / 220, 2);
        const cx = W / 2, cy = H * .45; ctx.fillStyle = '#0c1730'; rrect(ctx, cx - 120, cy - 100, 240, 180, 14, '#10224a', COL.grid); ctx.fillStyle = '#e8f1ff'; rrect(ctx, cx - 90, cy - 80, 180, 56, 8, '#06101f'); text(ctx, fmt(E, 2) + ' kWh', cx, cy - 52, { size: 26, weight: 700, color: COL.c });
        ctx.fillStyle = COL.dim; text(ctx, a[0], cx, cy, { size: 16, weight: 700 }); text(ctx, P + ' واط × ' + S.p.h + ' ساعة × ' + S.p.dd + ' يوم', cx, cy + 30, { size: 12, color: COL.dim }); text(ctx, '= ' + fmt(P / 1000, 3) + ' كيلوواط × ' + fmt(S.p.h * S.p.dd, 1) + ' ساعة', cx, cy + 52, { size: 12, color: COL.dim });
        text(ctx, 'التكلفة ≈ ' + fmt(cost, 2) + ' ريال', cx, H - 50, { size: 18, weight: 700, color: COL.a });
      }
    }
  });
};
