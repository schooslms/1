/* ===== التطبيق: التوجيه والواجهة ===== */
const { cats: CATS, exps: EXPS } = window.DATA;
const CCOL = { 'Describing Motion': '#4cc9f0', 'Acceleration': '#ff8a5c', 'Force': '#ffb547', 'Energy and Motion': '#7bd88f', 'Momentum': '#ff6b81', 'Simple Harmonic Motion': '#b392f0', 'Properties of Matter': '#38bdf8', 'Optics': '#f4d35e', 'Electricity': '#fb7185' };
const catOf = id => CATS.find(c => c.id === id);
const app = document.getElementById('app');
let current = null;

/* التقدم المحفوظ (تفضيل خفيف لكل متصفح) */
const store = {
  get() { try { return JSON.parse(localStorage.getItem('physlab-done') || '[]'); } catch (e) { return this._m || []; } },
  set(a) { try { localStorage.setItem('physlab-done', JSON.stringify(a)); } catch (e) { this._m = a; } }
};
const isDone = id => store.get().includes(id);
const toggleDone = id => { const a = store.get(); const i = a.indexOf(id); i >= 0 ? a.splice(i, 1) : a.push(id); store.set(a); return i < 0; };

function setActive(h) { document.querySelectorAll('nav.menu a').forEach(a => a.classList.toggle('on', a.getAttribute('href') === h)); }
function stopSim() { if (current) { current.destroy(); current = null; } }

function orbitSVG() {
  const ell = (rot, dur, col) => `<g transform="rotate(${rot} 150 150)"><ellipse cx="150" cy="150" rx="125" ry="46" fill="none" stroke="${col}" stroke-opacity=".35" stroke-width="1.5"/><circle r="7" fill="${col}"><animateMotion dur="${dur}s" repeatCount="indefinite" path="M25,150 a125,46 0 1,0 250,0 a125,46 0 1,0 -250,0"/></circle></g>`;
  return `<svg viewBox="0 0 300 300" aria-hidden="true"><defs><radialGradient id="nu"><stop offset="0" stop-color="#ffd08a"/><stop offset="1" stop-color="#ff7a45"/></radialGradient></defs>${ell(0, 5, '#4cc9f0')}${ell(60, 7, '#7bd88f')}${ell(120, 9, '#b392f0')}<circle cx="150" cy="150" r="20" fill="url(#nu)"><animate attributeName="r" values="20;23;20" dur="3s" repeatCount="indefinite"/></circle></svg>`;
}

function card(e, i) {
  const c = catOf(e.cat);
  return $('a', { class: 'card' + (isDone(e.id) ? ' done' : ''), href: '#exp-' + e.id, style: '--cc:' + CCOL[e.cat] },
    $('span', { class: 'num' }, String(e.id)), $('span', { class: 'tag' }, c.icon + ' ' + c.name), $('h4', {}, e.title));
}

/* ---------- الرئيسية ---------- */
function Home() {
  setActive('#home'); const done = store.get().length;
  const feat = [2, 19, 25, 40, 46, 56, 62, 66, 70].map(i => EXPS[i % EXPS.length]).filter((e, i, a) => a.findIndex(x => x.id === e.id) === i).slice(0, 6);
  const sims = new Set(EXPS.map(e => e.sim)).size;
  app.append($('div', { class: 'wrap' },
    $('section', { class: 'hero' },
      $('div', {}, $('h1', { html: 'معمل الفيزياء <em>الافتراضي</em>' }), $('p', {}, 'تجارب فيزيائية تفاعلية تعمل مباشرة في المتصفح: غيّر المتغيرات، شاهد النتائج، وتحقّق من القوانين بنفسك دون أجهزة أو تثبيت برامج.'),
        $('div', { class: 'cta' }, $('a', { class: 'btn primary big', href: '#experiments' }, '🔬 ابدأ التجارب'))),
      $('div', { class: 'orbit', html: orbitSVG() })),
    $('div', { class: 'stats' }, [[EXPS.length, 'تجربة'], [CATS.length, 'أقسام'], [sims, 'محاكاة تفاعلية'], [done, 'تجارب أنجزتَها']].map(([n, l]) => $('div', { class: 'stat' }, $('b', {}, String(n)), $('span', {}, l)))),
    $('div', { class: 'bar-prog', 'aria-label': 'التقدم' }, $('i', { style: 'width:' + Math.round(done / EXPS.length * 100) + '%' })),
    $('h2', { class: 'sec' }, 'أقسام الفيزياء'),
    $('div', { class: 'cats' }, CATS.map(c => { const n = EXPS.filter(e => e.cat === c.id).length; return $('a', { class: 'cat', href: '#cat-' + CATS.indexOf(c), style: '--cc:' + CCOL[c.id] }, $('div', { class: 'ic' }, c.icon), $('h3', {}, c.name), $('small', {}, n + ' تجارب')); })),
    $('h2', { class: 'sec' }, 'تجارب مقترحة'),
    $('div', { class: 'grid' }, feat.map(card))));
}

/* ---------- قائمة التجارب ---------- */
function List(cat) {
  setActive('#experiments'); let q = '', cur = cat || 'all';
  const grid = $('div', { class: 'grid' }), chips = $('div', { class: 'chips' }), cnt = $('div', { class: 'crumbs' });
  const norm = s => s.replace(/[ً-ْـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').toLowerCase();
  const paint = () => {
    chips.innerHTML = ''; [['all', 'الكل']].concat(CATS.map(c => [c.id, c.name])).forEach(([id, n]) => chips.append($('button', { class: 'chip' + (cur === id ? ' on' : ''), onclick: () => { cur = id; paint(); } }, n)));
    const list = EXPS.filter(e => (cur === 'all' || e.cat === cur) && (!q || norm(e.title).includes(norm(q)) || norm(catOf(e.cat).name).includes(norm(q))));
    grid.innerHTML = ''; list.length ? list.forEach(e => grid.append(card(e))) : grid.append($('div', { class: 'empty' }, 'لا توجد تجارب مطابقة للبحث'));
    cnt.textContent = list.length + ' تجربة';
  };
  const inp = $('input', { class: 'search', type: 'search', placeholder: 'ابحث عن تجربة… (مثال: نواس، احتكاك، عدسة)', 'aria-label': 'بحث' }); inp.oninput = () => { q = inp.value.trim(); paint(); };
  app.append($('div', { class: 'wrap' }, $('h2', { class: 'sec' }, 'جميع التجارب'), $('div', { class: 'tools' }, inp), chips, cnt, grid)); paint();
}

/* ---------- صفحة التجربة ---------- */
function Experiment(id) {
  const e = EXPS.find(x => x.id === +id); if (!e) return Home(); setActive('#experiments');
  const c = catOf(e.cat), idx = EXPS.indexOf(e), prev = EXPS[idx - 1], next = EXPS[idx + 1];
  const intro = e.text.find(t => /^في هذه التجربة|^سوف|^ستتعرف/.test(t)) || e.text[0] || '';
  const steps = e.text.filter(t => t !== intro);
  const ol = $('ol', {}); steps.forEach(t => { const opt = /^(أ\s*[-–]|-\s)/.test(t); ol.append($('li', { class: opt ? 'opt' : (/[؟?]|أكمل|ماذا|هل|أي /.test(t) ? 'q' : '') }, t)); });
  const simHost = $('div', {}), btn = $('button', { class: 'btn done-btn' + (isDone(e.id) ? ' on' : ''), onclick: () => { const on = toggleDone(e.id); btn.classList.toggle('on', on); btn.textContent = on ? '✓ تم إنجازها' : '☐ علّم كمنجزة'; } }, isDone(e.id) ? '✓ تم إنجازها' : '☐ علّم كمنجزة');
  app.append($('div', { class: 'wrap' },
    $('div', { class: 'crumbs' }, $('a', { href: '#home' }, 'الرئيسية'), ' ‹ ', $('a', { href: '#cat-' + CATS.indexOf(c) }, c.name), ' ‹ ', e.title),
    $('div', { class: 'exp-h' }, $('h1', {}, e.title), btn),
    $('div', { class: 'layout' }, simHost,
      $('aside', { class: 'panel' }, $('h3', {}, 'هدف التجربة'), $('p', { class: 'aim' }, intro), steps.length ? $('h3', { style: 'margin-top:14px' }, 'الخطوات والأسئلة') : null, steps.length ? ol : null)),
    $('div', { class: 'nav2' }, next ? $('a', { class: 'btn', href: '#exp-' + next.id }, '→ ' + next.title) : $('span'), prev ? $('a', { class: 'btn', href: '#exp-' + prev.id }, prev.title + ' ←') : $('span'))));
  try { current = SIMS[e.sim](simHost, e.pre || {}); } catch (err) { console.error(err); simHost.append($('div', { class: 'panel' }, 'تعذّر تشغيل المحاكاة.')); }
  window.scrollTo(0, 0);
}

function About() {
  setActive('#about');
  app.append($('div', { class: 'wrap' }, $('h2', { class: 'sec' }, 'عن الموقع'), $('div', { class: 'about' },
    $('div', { class: 'panel' }, $('h3', {}, 'ما هو؟'), $('p', {}, 'موقع تجارب فيزيائية تفاعلية يعيد بناء تجارب برنامج المختبرات الافتراضية (Crocodile Physics) لتعمل على الجوال والحاسوب دون تثبيت.')),
    $('div', { class: 'panel' }, $('h3', {}, 'كيف أستخدمه؟'), $('p', {}, 'اختر قسمًا ثم تجربة، اضغط «تشغيل»، وغيّر المتغيرات بالمنزلقات. اقرأ القراءات الظاهرة وقارنها بالقانون المذكور أسفل المحاكاة.')),
    $('div', { class: 'panel' }, $('h3', {}, 'ملاحظة علمية'), $('p', {}, 'المحاكاة مبسّطة لأغراض التعليم (إهمال مقاومة الهواء ما لم يُذكر). القيم تقريبية وقد تختلف قليلًا عن البرنامج الأصلي.')))));
}

function route() {
  stopSim(); app.innerHTML = '';
  const h = (location.hash || '#home').slice(1); let m;
  if ((m = h.match(/^exp-(\d+)$/))) Experiment(m[1]); else if ((m = h.match(/^cat-(\d+)$/))) List(CATS[+m[1]]?.id); else if (h === 'experiments') List(null); else Home();
  if (!h.startsWith('exp-')) window.scrollTo(0, 0);
}
window.addEventListener('hashchange', route); route();
