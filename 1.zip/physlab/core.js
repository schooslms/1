/* ===== أدوات مشتركة وإطار المحاكاة ===== */
const $ = (t, a = {}, ...c) => {
  const e = document.createElement(t);
  for (const k in a) {
    if (k === 'class') e.className = a[k];
    else if (k.startsWith('on')) e[k] = a[k];
    else if (k === 'html') e.innerHTML = a[k];
    else e.setAttribute(k, a[k]);
  }
  c.flat().forEach(x => x != null && e.append(x));
  return e;
};
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const fmt = (v, d = 2) => {
  if (!isFinite(v)) return '—';
  let s = Number(v).toFixed(d);
  if (s.includes('.')) s = s.replace(/\.?0+$/, '');
  return s === '-0' || s === '' ? '0' : s;
};
const TAU = Math.PI * 2, D2R = Math.PI / 180;
const COL = { ink: '#e8f1ff', dim: '#8aa0c0', grid: 'rgba(120,160,220,.14)', a: '#ffb547', b: '#4cc9f0', c: '#7bd88f', d: '#ff6b81', e: '#b392f0', bg: '#0c1730' };

function arrow(ctx, x1, y1, x2, y2, color = COL.a, w = 3, head = 9) {
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy);
  if (L < 1) return;
  const ux = dx / L, uy = dy / L, h = Math.min(head, L * .6);
  ctx.save(); ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = w; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - ux * h * .7, y2 - uy * h * .7); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(x2 - ux * h - uy * h * .5, y2 - uy * h + ux * h * .5);
  ctx.lineTo(x2 - ux * h + uy * h * .5, y2 - uy * h - ux * h * .5); ctx.closePath(); ctx.fill(); ctx.restore();
}
function text(ctx, s, x, y, o = {}) {
  ctx.save(); ctx.fillStyle = o.color || COL.ink; ctx.font = `${o.weight || 500} ${o.size || 13}px Tahoma, "Segoe UI", sans-serif`;
  ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle'; ctx.direction = /[\u0600-\u06FF]/.test(s) ? 'rtl' : 'ltr';
  ctx.fillText(s, x, y); ctx.restore();
}
function rrect(ctx, x, y, w, h, r, fill, stroke) {
  ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, r) : ctx.rect(x, y, w, h);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.5; ctx.stroke(); }
}
function bg(ctx, W, H, grid = 40) {
  const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#0f2145'); g.addColorStop(1, '#0a1226');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  if (grid) {
    ctx.strokeStyle = COL.grid; ctx.lineWidth = 1; ctx.beginPath();
    for (let x = 0; x < W; x += grid) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
    for (let y = 0; y < H; y += grid) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
    ctx.stroke();
  }
}

/* منحنى بياني بسيط */
class Graph {
  constructor(opt = {}) { this.s = []; this.opt = opt; }
  clear() { this.s = []; }
  add(i, x, y) { (this.s[i] = this.s[i] || []).push([x, y]); }
  draw(ctx, X, Y, W, H, o = {}) {
    const all = this.s.flat();
    ctx.save();
    rrect(ctx, X, Y, W, H, 8, 'rgba(6,12,28,.72)', 'rgba(120,160,220,.25)');
    const pad = { l: 40, r: 12, t: 24, b: 22 };
    const px = X + pad.l, py = Y + pad.t, pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
    let x0 = o.x0 ?? 0, x1 = o.x1 ?? Math.max(1, ...all.map(p => p[0]));
    let y0 = o.y0, y1 = o.y1;
    if (y0 == null || y1 == null) {
      let lo = Math.min(0, ...all.map(p => p[1])), hi = Math.max(0, ...all.map(p => p[1]));
      if (hi - lo < 1e-9) { hi = lo + 1; }
      const m = (hi - lo) * .1; y0 = o.y0 ?? lo - (lo < 0 ? m : 0); y1 = o.y1 ?? hi + m;
    }
    const sx = v => px + (v - x0) / (x1 - x0 || 1) * pw, sy = v => py + ph - (v - y0) / (y1 - y0 || 1) * ph;
    ctx.strokeStyle = COL.grid; ctx.lineWidth = 1; ctx.beginPath();
    for (let i = 0; i <= 4; i++) { const gy = py + ph * i / 4; ctx.moveTo(px, gy); ctx.lineTo(px + pw, gy); const gx = px + pw * i / 4; ctx.moveTo(gx, py); ctx.lineTo(gx, py + ph); }
    ctx.stroke();
    ctx.strokeStyle = 'rgba(200,220,255,.55)'; ctx.beginPath();
    const zy = sy(0); if (zy > py && zy < py + ph) { ctx.moveTo(px, zy); ctx.lineTo(px + pw, zy); }
    ctx.moveTo(px, py); ctx.lineTo(px, py + ph); ctx.stroke();
    for (let i = 0; i <= 4; i++) {
      text(ctx, fmt(y1 - (y1 - y0) * i / 4, Math.abs(y1 - y0) < 5 ? 2 : 0), px - 5, py + ph * i / 4, { align: 'right', size: 10, color: COL.dim });
      text(ctx, fmt(x0 + (x1 - x0) * i / 4, 1), px + pw * i / 4, py + ph + 11, { size: 10, color: COL.dim });
    }
    text(ctx, o.title || '', X + W / 2, Y + 11, { size: 12, weight: 700 });
    const cols = o.colors || [COL.a, COL.b, COL.c];
    if (o.area) {
      const s = this.s[0] || []; ctx.fillStyle = 'rgba(255,181,71,.18)'; ctx.beginPath(); ctx.moveTo(sx(s[0]?.[0] ?? 0), sy(0));
      s.forEach(p => ctx.lineTo(sx(p[0]), sy(p[1]))); if (s.length) ctx.lineTo(sx(s[s.length - 1][0]), sy(0)); ctx.closePath(); ctx.fill();
    }
    ctx.save(); ctx.beginPath(); ctx.rect(px, py - 2, pw, ph + 4); ctx.clip();
    this.s.forEach((s, i) => {
      ctx.strokeStyle = cols[i % cols.length]; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.beginPath();
      s.forEach((p, k) => k ? ctx.lineTo(sx(p[0]), sy(p[1])) : ctx.moveTo(sx(p[0]), sy(p[1]))); ctx.stroke();
    });
    ctx.restore();
    ctx.restore();
    return { sx, sy };
  }
}

/* إطار المحاكاة: لوحة رسم + أزرار تحكم + قراءات */
function Sim(root, def) {
  root.innerHTML = '';
  const cv = $('canvas', { class: 'cv' });
  const stage = $('div', { class: 'stage' }, cv);
  const bar = $('div', { class: 'bar' });
  const ctrls = $('div', { class: 'ctrls' });
  const reads = $('div', { class: 'reads' });
  const box = $('div', { class: 'simbox' }, stage, def.static ? null : bar, $('div', { class: 'under' }, ctrls, reads));
  root.append(box);
  const ctx = cv.getContext('2d');
  const S = { ctx, cv, W: 800, H: def.h || 420, t: 0, running: false, p: {}, ptr: { x: 0, y: 0, down: false }, drag: null };
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  S.resize = () => {
    const w = Math.max(280, stage.clientWidth), mobile = w < 560;
    S.W = w; S.H = def.hm && mobile ? def.hm : (def.h || 420);
    cv.width = w * dpr; cv.height = S.H * dpr; cv.style.height = S.H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); S.dirty = true; def.onResize && def.onResize(S);
  };
  const ro = new ResizeObserver(S.resize); ro.observe(stage);

  const playBtn = $('button', { class: 'btn primary' }, '▶ تشغيل');
  const resetBtn = $('button', { class: 'btn' }, '↺ إعادة');
  const setRun = v => { S.running = v; playBtn.textContent = v ? '⏸ إيقاف مؤقت' : '▶ تشغيل'; playBtn.classList.toggle('on', v); };
  S.setRun = setRun; S.reset = () => resetBtn.click();
  playBtn.onclick = () => setRun(!S.running);
  resetBtn.onclick = () => { S.t = 0; def.reset && def.reset(S); setRun(!!def.auto); S.dirty = true; };
  bar.append(playBtn, resetBtn);
  if (def.speed !== false) {
    S.speed = 1;
    const sp = $('select', { class: 'sel', 'aria-label': 'سرعة المحاكاة', onchange: e => S.speed = +e.target.value }, [['0.25', '×0.25 بطيء'], ['0.5', '×0.5'], ['1', '×1 عادي'], ['2', '×2 سريع']].map(([v, l]) => $('option', { value: v, selected: v === '1' ? '' : null }, l)));
    sp.value = '1'; bar.append($('label', { class: 'spd' }, 'السرعة ', sp));
  }

  S.slider = (key, label, min, max, step, val, unit = '', o = {}) => {
    S.p[key] = val;
    const out = $('output', {}, fmt(val, o.d ?? 2) + (unit ? ' ' + unit : ''));
    const inp = $('input', { type: 'range', min, max, step, value: val, 'aria-label': label });
    const row = $('label', { class: 'row' }, $('span', { class: 'lb' }, label), inp, out);
    inp.oninput = () => { S.p[key] = +inp.value; out.textContent = fmt(+inp.value, o.d ?? 2) + (unit ? ' ' + unit : ''); def.onParam && def.onParam(S, key); S.dirty = true; if (o.reset) resetBtn.click(); };
    ctrls.append(row); return { inp, row, set: v => { inp.value = v; inp.oninput(); } };
  };
  S.select = (key, label, opts, val) => {
    S.p[key] = val ?? opts[0][0];
    const sel = $('select', { class: 'sel', 'aria-label': label }, opts.map(([v, l]) => $('option', { value: v }, l)));
    sel.value = S.p[key];
    sel.onchange = () => { S.p[key] = isNaN(+sel.value) || sel.value === '' ? sel.value : +sel.value; def.onParam && def.onParam(S, key); S.dirty = true; if (!S.noResetOnSelect && !def.noResetOnSelect) resetBtn.click(); };
    ctrls.append($('label', { class: 'row' }, $('span', { class: 'lb' }, label), sel)); return sel;
  };
  S.check = (key, label, val) => {
    S.p[key] = !!val;
    const c = $('input', { type: 'checkbox' }); c.checked = !!val;
    c.onchange = () => { S.p[key] = c.checked; def.onParam && def.onParam(S, key); S.dirty = true; };
    ctrls.append($('label', { class: 'row chk' }, c, $('span', {}, label))); return c;
  };
  S.ctrls = ctrls;
  S.read = (label, unit = '', cls = '') => {
    const v = $('b', {}, '—'); reads.append($('div', { class: 'rd ' + cls }, $('span', {}, label), $('span', { class: 'val' }, v, unit ? ' ' + unit : '')));
    return (x, d = 2) => v.textContent = typeof x === 'string' ? x : fmt(x, d);
  };
  S.btn = (label, fn) => { const b = $('button', { class: 'btn small' }, label); b.onclick = fn; ctrls.append(b); return b; };
  S.note = (html) => { const n = $('div', { class: 'simnote', html }); box.append(n); return n; };

  /* مؤشر الفأرة/اللمس للسحب */
  const pos = e => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * (S.W / r.width), y: (e.clientY - r.top) * (S.H / r.height) }; };
  cv.addEventListener('pointerdown', e => { Object.assign(S.ptr, pos(e), { down: true }); def.down && def.down(S); cv.setPointerCapture(e.pointerId); if (S.drag) e.preventDefault(); });
  cv.addEventListener('pointermove', e => { Object.assign(S.ptr, pos(e)); if (S.ptr.down && def.move) { def.move(S); S.dirty = true; } });
  const up = () => { S.ptr.down = false; S.drag = null; def.up && def.up(S); };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  cv.style.touchAction = 'pan-y';

  def.init(S);
  def.reset && def.reset(S);
  S.resize();
  setRun(!!def.auto);

  let last = performance.now(), raf = 0, dead = false;
  const loop = now => {
    if (dead) return;
    const dt = Math.min(.04, (now - last) / 1000); last = now;
    if (S.running) {
      const h = dt * S.speed, n = Math.max(1, Math.ceil(h / .004));
      for (let i = 0; i < n; i++) { S.t += h / n; def.step && def.step(S, h / n); }
      S.dirty = true;
    }
    if (S.dirty || S.running) { S.dirty = false; def.draw(S); }
    raf = requestAnimationFrame(loop);
  };
  raf = requestAnimationFrame(loop);
  return { destroy() { dead = true; cancelAnimationFrame(raf); ro.disconnect(); } };
}
window.SIMS = {};
