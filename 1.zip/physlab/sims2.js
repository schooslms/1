/* ===== محاكاة 2: الحركة، المتجهات، الدوران، الاتزان، الجاذبية العامة، الطاقة ===== */

SIMS.kinematics = (root, pre) => {
  const mode = pre.mode; let rd = {}, gx = new Graph(), gv = new Graph();
  const kin = (S, t) => {
    if (mode === 'uniform') return { x: S.p.v * t, v: S.p.v, a: 0 };
    if (mode === 'accel') { let v = S.p.v0 + S.p.a * t; const stopT = (S.p.a * S.p.v0 < 0) ? -S.p.v0 / S.p.a : Infinity; if (t > stopT) return { x: S.p.v0 * stopT + .5 * S.p.a * stopT * stopT, v: 0, a: 0 }; return { x: S.p.v0 * t + .5 * S.p.a * t * t, v, a: S.p.a }; }
    const t1 = S.p.t1, t2 = S.p.t2; const s1 = S.p.v1 * t1;
    if (t <= t1) return { x: S.p.v1 * t, v: S.p.v1, a: 0 }; if (t <= t1 + t2) return { x: s1, v: 0, a: 0 };
    return { x: s1 - S.p.v3 * (t - t1 - t2), v: -S.p.v3, a: 0 };
  };
  return Sim(root, {
    h: 520, hm: 640,
    init(S) {
      if (mode === 'uniform') S.slider('v', 'السرعة الثابتة', 1, 20, 1, 8, 'م/ث', { d: 0 });
      else if (mode === 'accel') { S.slider('v0', 'السرعة الابتدائية', 0, 30, 1, pre.v0 ?? 2, 'م/ث', { d: 0 }); S.slider('a', 'التسارع', -6, 6, .5, pre.a ?? 2, 'م/ث²', { d: 1 }); }
      else { S.slider('v1', 'سرعة الذهاب', 1, 12, 1, 6, 'م/ث', { d: 0 }); S.slider('t1', 'زمن الذهاب', 1, 5, .5, 3, 'ث', { d: 1 }); S.slider('t2', 'زمن التوقف', 0, 4, .5, 2, 'ث', { d: 1 }); S.slider('v3', 'سرعة العودة', 1, 12, 1, 4, 'م/ث', { d: 0 }); }
      if (pre.slope) { S.slider('ta', 'الزمن t₁', 0, 9, .5, 2, 'ث', { d: 1 }); S.slider('tb', 'الزمن t₂', 1, 10, .5, 8, 'ث', { d: 1 }); rd.sl = S.read('الميل Δv/Δt (= التسارع)', 'م/ث²', 'hi'); }
      rd.t = S.read('الزمن', 'ث'); rd.x = S.read('المسافة x', 'م'); rd.v = S.read('السرعة v', 'م/ث');
      if (pre.area) rd.area = S.read('المساحة تحت منحنى (v-t) = الإزاحة', 'م', 'hi');
      S.note(pre.slope ? 'ميل منحنى (السرعة-الزمن) يساوي التسارع: a = Δv / Δt. حرّك t₁ و t₂ لترى ثبات الميل.' : pre.area ? 'المساحة المحصورة بين منحنى (السرعة-الزمن) ومحور الزمن تساوي الإزاحة.' : 'ميل منحنى (المسافة-الزمن) يساوي السرعة، وميل منحنى (السرعة-الزمن) يساوي التسارع.');
    },
    reset(S) { gx.clear(); gv.clear(); },
    onParam(S) { S.reset(); },
    step(S, dt) { const k = kin(S, S.t); gx.add(0, S.t, k.x); gv.add(0, S.t, k.v); if (S.t >= 10) { S.t = 10; S.setRun(false); } },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const k = kin(S, S.t), wide = W >= 640;
      const roadY = 90; ctx.fillStyle = '#26364f'; ctx.fillRect(0, roadY, W, 30);
      const cx = W * .5, off = k.x * 14; for (let x = -(off % 90) - 90; x < W + 90; x += 90) { ctx.fillStyle = '#e8f1ff'; ctx.fillRect(x, roadY + 13, 40, 4); }
      for (let m = Math.floor((k.x - cx / 14) / 10) * 10; m < k.x + cx / 14 + 10; m += 10) { const px = cx + (m - k.x) * 14; if (px > 0 && px < W) { ctx.fillStyle = COL.dim; ctx.fillRect(px, roadY + 30, 2, 10); text(ctx, m + ' م', px, roadY + 50, { size: 10, color: COL.dim }); } }
      rrect(ctx, cx - 35, roadY - 26, 70, 22, 8, COL.a); rrect(ctx, cx - 16, roadY - 42, 36, 18, 6, '#ffd08a'); ctx.fillStyle = '#0a1226'; [-20, 20].forEach(d => { ctx.beginPath(); ctx.arc(cx + d, roadY - 2, 8, 0, TAU); ctx.fill(); });
      if (Math.abs(k.v) > .1) arrow(ctx, cx, roadY - 56, cx + Math.sign(k.v) * Math.min(100, Math.abs(k.v) * 5), roadY - 56, COL.c, 3);
      rd.t(S.t); rd.x(k.x); rd.v(k.v); if (rd.area) { let A = 0; const n = 200; for (let i = 0; i < n; i++) A += kin(S, S.t * (i + .5) / n).v * S.t / n; rd.area(A); }
      const gy0 = 150, gh = wide ? H - gy0 - 12 : (H - gy0 - 20) / 2, gw = wide ? W / 2 - 14 : W - 16;
      const o1 = gx.draw(ctx, wide ? W / 2 + 6 : 8, gy0, gw, gh, { x0: 0, x1: 10, y0: Math.min(0, ...[...Array(21).keys()].map(i => kin(S, i / 2).x)) * 1.1, y1: Math.max(10, ...[...Array(21).keys()].map(i => kin(S, i / 2).x)) * 1.05, title: 'المسافة (م) — الزمن (ث)' });
      const vs = [...Array(21).keys()].map(i => kin(S, i / 2).v), vmin = Math.min(0, ...vs), vmax = Math.max(5, ...vs);
      const o2 = gv.draw(ctx, 8, wide ? gy0 : gy0 + gh + 10, gw, gh, { x0: 0, x1: 10, y0: vmin * 1.1, y1: vmax * 1.1, area: !!pre.area, colors: [COL.b], title: 'السرعة (م/ث) — الزمن (ث)' });
      if (pre.slope) {
        const ta = S.p.ta, tb = Math.max(S.p.tb, ta + .5), va = kin(S, ta).v, vb = kin(S, tb).v;
        ctx.strokeStyle = COL.d; ctx.lineWidth = 2; ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.moveTo(o2.sx(ta), o2.sy(va)); ctx.lineTo(o2.sx(tb), o2.sy(va)); ctx.lineTo(o2.sx(tb), o2.sy(vb)); ctx.lineTo(o2.sx(ta), o2.sy(va)); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = COL.d; [[ta, va], [tb, vb]].forEach(([a, b]) => { ctx.beginPath(); ctx.arc(o2.sx(a), o2.sy(b), 5, 0, TAU); ctx.fill(); }); rd.sl((vb - va) / (tb - ta));
      }
    }
  });
};

SIMS.vectors = (root, pre) => {
  const mode = pre.mode; let rd = {};
  return Sim(root, {
    h: 420, hm: 460, static: true,
    init(S) {
      if (mode === 'resultant') {
        S.slider('F1', 'القوة الأولى F₁', 0, 100, 1, 60, 'N', { d: 0 }); S.slider('F2', 'القوة الثانية F₂', 0, 100, 1, 40, 'N', { d: 0 }); S.slider('al', 'الزاوية بين القوتين', 0, 180, 1, pre.angle ?? 60, '°', { d: 0 });
        rd.R = S.read('المحصلة R', 'N', 'hi'); rd.be = S.read('اتجاه المحصلة', '°');
        S.note('R² = F₁² + F₂² + 2F₁F₂ cos α. عند 0° تُجمع القوتان، وعند 180° تُطرح إحداهما من الأخرى، وعند 90° تنطبق نظرية فيثاغورس.');
      } else if (mode === 'components') {
        S.slider('F', 'مقدار القوة F', 0, 100, 1, 70, 'N', { d: 0 }); S.slider('th', 'الزاوية θ مع الأفقي', 0, 360, 1, 35, '°', { d: 0 });
        rd.fx = S.read('المركبة الأفقية Fx = F cos θ', 'N', 'hi'); rd.fy = S.read('المركبة الرأسية Fy = F sin θ', 'N', 'hi');
        S.note('يمكن تحليل أي قوة إلى مركبتين متعامدتين: أفقية ورأسية.');
      } else if (mode === 'coords') {
        S.slider('x', 'الإحداثي x', -8, 8, 1, 5, '', { d: 0 }); S.slider('y', 'الإحداثي y', -6, 6, 1, 3, '', { d: 0 });
        rd.r = S.read('البعد عن نقطة الأصل r = √(x²+y²)', 'وحدة'); rd.th = S.read('الزاوية مع المحور x', '°'); rd.q = S.read('الربع', '');
        S.note('يُحدَّد موضع النقطة في المستوى بإحداثييها (x , y) بالنسبة إلى نقطة الأصل.');
      } else if (mode === 'reference') {
        S.select('ref', 'نقطة المرجع (الأصل)', [['0', 'المدرسة'], ['1', 'المسجد'], ['2', 'المكتبة']], '0');
        rd.p0 = S.read('موضع المدرسة', 'م'); rd.p1 = S.read('موضع المسجد', 'م'); rd.p2 = S.read('موضع المكتبة', 'م');
        S.note('موضع الجسم يتغير بتغير نقطة المرجع، لكن المسافة بين جسمين لا تتغير.'); S.noResetOnSelect = true;
      } else {
        S.slider('d1', 'المسافة الأولى (شرقًا)', 1, 10, 1, 6, 'كم', { d: 0 }); S.slider('d2', 'المسافة الثانية', 1, 10, 1, 4, 'كم', { d: 0 }); S.slider('ph', 'اتجاه المسار الثاني', 0, 180, 5, 90, '°', { d: 0 });
        rd.dist = S.read('المسافة المقطوعة (كمية قياسية)', 'كم'); rd.disp = S.read('الإزاحة (كمية متجهة)', 'كم', 'hi'); rd.ang = S.read('اتجاه الإزاحة', '°');
        S.note('المسافة تُجمع جمعًا عاديًا، أما الإزاحة فمتجه يصل نقطة البداية بالنهاية، ومقدارها أقل أو يساوي المسافة.');
      }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 40); const cx = W / 2, cy = H / 2;
      if (mode === 'resultant') {
        const s = Math.min(W, H) / 260, a = S.p.al * D2R, f1 = { x: S.p.F1 * s, y: 0 }, f2 = { x: S.p.F2 * s * Math.cos(a), y: -S.p.F2 * s * Math.sin(a) };
        const ox = cx - (f1.x + f2.x) / 2, oy = cy - (f1.y + f2.y) / 2;
        ctx.strokeStyle = 'rgba(255,255,255,.3)'; ctx.setLineDash([5, 5]); ctx.beginPath(); ctx.moveTo(ox + f1.x, oy); ctx.lineTo(ox + f1.x + f2.x, oy + f2.y); ctx.lineTo(ox + f2.x, oy + f2.y); ctx.stroke(); ctx.setLineDash([]);
        arrow(ctx, ox, oy, ox + f1.x, oy, COL.a, 4); arrow(ctx, ox, oy, ox + f2.x, oy + f2.y, COL.b, 4); arrow(ctx, ox, oy, ox + f1.x + f2.x, oy + f2.y, COL.d, 5, 13);
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ox, oy, 6, 0, TAU); ctx.fill();
        text(ctx, 'F₁', ox + f1.x / 2, oy + 16, { color: COL.a, weight: 700 }); text(ctx, 'F₂', ox + f2.x / 2 - 10, oy + f2.y / 2 - 10, { color: COL.b, weight: 700 }); text(ctx, 'R', ox + (f1.x + f2.x) / 2 + 12, oy + f2.y / 2 - 14, { color: COL.d, weight: 700 });
        const R = Math.hypot(S.p.F1 + S.p.F2 * Math.cos(a), S.p.F2 * Math.sin(a)); rd.R(R); rd.be(Math.atan2(S.p.F2 * Math.sin(a), S.p.F1 + S.p.F2 * Math.cos(a)) / D2R, 1);
      } else if (mode === 'components') {
        const s = Math.min(W, H) / 250, th = S.p.th * D2R, fx = S.p.F * Math.cos(th) * s, fy = -S.p.F * Math.sin(th) * s;
        ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(30, cy); ctx.lineTo(W - 30, cy); ctx.moveTo(cx, 20); ctx.lineTo(cx, H - 20); ctx.stroke(); text(ctx, 'x', W - 24, cy - 12, { color: COL.dim }); text(ctx, 'y', cx + 12, 26, { color: COL.dim });
        ctx.setLineDash([5, 5]); ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.beginPath(); ctx.moveTo(cx + fx, cy + fy); ctx.lineTo(cx + fx, cy); ctx.moveTo(cx + fx, cy + fy); ctx.lineTo(cx, cy + fy); ctx.stroke(); ctx.setLineDash([]);
        arrow(ctx, cx, cy, cx + fx, cy, COL.b, 4); arrow(ctx, cx, cy, cx, cy + fy, COL.c, 4); arrow(ctx, cx, cy, cx + fx, cy + fy, COL.a, 5, 13);
        text(ctx, 'Fx', cx + fx / 2, cy + 18, { color: COL.b, weight: 700 }); text(ctx, 'Fy', cx - 18, cy + fy / 2, { color: COL.c, weight: 700 }); text(ctx, 'F', cx + fx / 2 + 14, cy + fy / 2 - 14, { color: COL.a, weight: 700 });
        ctx.strokeStyle = COL.dim; ctx.beginPath(); ctx.arc(cx, cy, 36, 0, -th, th > 0 ? true : false); ctx.stroke(); text(ctx, 'θ', cx + 48 * Math.cos(-th / 2), cy + 48 * Math.sin(-th / 2), { color: COL.dim });
        rd.fx(S.p.F * Math.cos(th)); rd.fy(S.p.F * Math.sin(th));
      } else if (mode === 'coords') {
        const u = Math.min((W - 60) / 18, (H - 40) / 14);
        ctx.strokeStyle = COL.grid; ctx.lineWidth = 1; ctx.beginPath(); for (let i = -9; i <= 9; i++) { ctx.moveTo(cx + i * u, cy - 7 * u); ctx.lineTo(cx + i * u, cy + 7 * u); } for (let j = -7; j <= 7; j++) { ctx.moveTo(cx - 9 * u, cy + j * u); ctx.lineTo(cx + 9 * u, cy + j * u); } ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx - 9 * u, cy); ctx.lineTo(cx + 9 * u, cy); ctx.moveTo(cx, cy - 7 * u); ctx.lineTo(cx, cy + 7 * u); ctx.stroke();
        const px = cx + S.p.x * u, py = cy - S.p.y * u; ctx.setLineDash([5, 4]); ctx.strokeStyle = COL.b; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px, cy); ctx.moveTo(px, py); ctx.lineTo(cx, py); ctx.stroke(); ctx.setLineDash([]);
        arrow(ctx, cx, cy, px, py, COL.a, 3); ctx.fillStyle = COL.d; ctx.beginPath(); ctx.arc(px, py, 7, 0, TAU); ctx.fill(); text(ctx, '(' + S.p.x + ' , ' + S.p.y + ')', px + 10, py - 16, { weight: 700, align: 'left' });
        const r = Math.hypot(S.p.x, S.p.y); rd.r(r); let an = Math.atan2(S.p.y, S.p.x) / D2R; if (an < 0) an += 360; rd.th(an, 1);
        rd.q((S.p.x === 0 || S.p.y === 0) ? 'على أحد المحورين' : S.p.x > 0 && S.p.y > 0 ? 'الأول' : S.p.x < 0 && S.p.y > 0 ? 'الثاني' : S.p.x < 0 ? 'الثالث' : 'الرابع');
      } else if (mode === 'reference') {
        const names = ['المدرسة', 'المسجد', 'المكتبة'], pos = [-60, 20, 90], cols = [COL.a, COL.b, COL.c], u = (W - 100) / 330, y = cy;
        ctx.fillStyle = '#26364f'; ctx.fillRect(30, y, W - 60, 8); const ref = +S.p.ref;
        for (let m = -100; m <= 100; m += 20) { ctx.fillStyle = COL.dim; ctx.fillRect(cx + (m - pos[ref]) * u, y + 8, 2, 8); text(ctx, String(m), cx + (m - pos[ref]) * u, y + 28, { size: 10, color: COL.dim }); }
        names.forEach((n, i) => { const x = cx + (pos[i] - pos[ref]) * u; ctx.fillStyle = cols[i]; ctx.beginPath(); ctx.arc(x, y - 22, 14, 0, TAU); ctx.fill(); text(ctx, n, x, y - 52, { weight: 700, color: cols[i] }); if (i === ref) text(ctx, 'المرجع (0)', x, y - 78, { size: 11, color: COL.d }); rd['p' + i](pos[i] - pos[ref], 0); });
        arrow(ctx, cx - 0, y + 56, cx + (pos[(ref + 1) % 3] - pos[ref]) * u, y + 56, COL.d, 2.5); text(ctx, 'موضع ' + names[(ref + 1) % 3] + ' بالنسبة للمرجع', cx + (pos[(ref + 1) % 3] - pos[ref]) * u / 2, y + 74, { size: 12, color: COL.dim });
      } else {
        const d1 = S.p.d1, d2 = S.p.d2, ph = S.p.ph * D2R, p0 = { x: 0, y: 0 }, p1 = { x: d1, y: 0 }, p2 = { x: d1 + d2 * Math.cos(ph), y: d2 * Math.sin(ph) };
        const minx = Math.min(0, p2.x), maxx = Math.max(d1, p2.x), maxy = Math.max(1, p2.y), s = Math.min((W - 120) / (maxx - minx + .01), (H - 120) / (maxy + .01));
        const X = x => 60 + (x - minx) * s, Y = y => H - 60 - y * s;
        arrow(ctx, X(p0.x), Y(p0.y), X(p1.x), Y(p1.y), COL.a, 3); arrow(ctx, X(p1.x), Y(p1.y), X(p2.x), Y(p2.y), COL.b, 3); arrow(ctx, X(p0.x), Y(p0.y), X(p2.x), Y(p2.y), COL.d, 4.5, 12);
        [[p0, 'البداية'], [p2, 'النهاية']].forEach(([p, n]) => { ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(X(p.x), Y(p.y), 6, 0, TAU); ctx.fill(); text(ctx, n, X(p.x), Y(p.y) + 20, { size: 12 }); });
        text(ctx, 'المسار: ' + (d1 + d2) + ' كم', W / 2, 26, { color: COL.a, weight: 700 }); const D = Math.hypot(p2.x, p2.y); text(ctx, 'الإزاحة: ' + fmt(D, 2) + ' كم', W / 2, 48, { color: COL.d, weight: 700 });
        rd.dist(d1 + d2, 0); rd.disp(D); rd.ang(Math.atan2(p2.y, p2.x) / D2R, 1);
      }
    }
  });
};

SIMS.circular = (root, pre) => {
  let ang = 0, rd = {}; const gr = new Graph();
  return Sim(root, {
    h: 400, hm: 560, auto: true,
    init(S) {
      S.slider('r', pre.vary === 'r' ? 'طول القضيب (نصف القطر) — غيّره' : 'نصف القطر r', .3, 2, .1, 1, 'م', { d: 1 }); S.slider('m', pre.vary === 'm' ? 'كتلة الكرة — غيّرها' : 'كتلة الكرة m', .2, 4, .2, 1, 'كجم', { d: 1 }); S.slider('v', 'السرعة المماسية v', .5, 6, .5, 1, 'م/ث', { d: 1 });
      rd.w = S.read('السرعة الزاوية ω = v/r', 'rad/s'); rd.ac = S.read('التسارع المركزي = v²/r', 'م/ث²'); rd.F = S.read('قوة الشد (المركزية) F = mv²/r', 'N', 'hi');
      S.note(pre.vary === 'r' ? 'عند ثبات الكتلة والسرعة تتناسب القوة المركزية عكسيًا مع نصف القطر.' : 'عند ثبات نصف القطر والسرعة تتناسب القوة المركزية طرديًا مع الكتلة.');
    },
    reset(S) { ang = 0; }, onParam() { },
    step(S, dt) { ang += S.p.v / S.p.r * dt; },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const wide = W >= 640, sw = wide ? W * .55 : W, sh = wide ? H : H * .62, cx = sw / 2, cy = sh / 2, sc = Math.min(sw, sh) / 2 / 2.5;
      const R = S.p.r * sc, bx = cx + R * Math.cos(ang), by = cy + R * Math.sin(ang), F = S.p.m * S.p.v ** 2 / S.p.r;
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = '#cfe3ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(bx, by); ctx.stroke(); ctx.fillStyle = '#9fb7e0'; ctx.beginPath(); ctx.arc(cx, cy, 8, 0, TAU); ctx.fill();
      ctx.fillStyle = COL.a; ctx.beginPath(); ctx.arc(bx, by, 10 + S.p.m * 3, 0, TAU); ctx.fill(); text(ctx, fmt(S.p.m, 1), bx, by, { color: '#06101f', weight: 700, size: 11 });
      const ux = Math.cos(ang), uy = Math.sin(ang); arrow(ctx, bx, by, bx - ux * Math.min(120, F * 6 + 20), by - uy * Math.min(120, F * 6 + 20), COL.d, 4); arrow(ctx, bx, by, bx - uy * S.p.v * 14, by + ux * S.p.v * 14, COL.b, 3);
      text(ctx, 'القوة المركزية', bx - ux * 70 + 10, by - uy * 70 - 14, { size: 11, color: COL.d }); text(ctx, 'v', bx - uy * S.p.v * 14, by + ux * S.p.v * 14 + 12, { color: COL.b });
      rd.w(S.p.v / S.p.r); rd.ac(S.p.v ** 2 / S.p.r); rd.F(F);
      const gx = wide ? sw : 0, gy = wide ? 0 : sh, gw = wide ? W - sw : W, gh = wide ? H : H - sh, g2 = new Graph(), vr = pre.vary === 'r', N = 40; g2.s[0] = [];
      for (let i = 0; i <= N; i++) { const x = vr ? .3 + 1.7 * i / N : .2 + 3.8 * i / N; g2.s[0].push([x, vr ? S.p.m * S.p.v ** 2 / x : x * S.p.v ** 2 / S.p.r]); }
      const o = g2.draw(ctx, gx + 8, gy + 8, gw - 16, gh - 16, { x0: vr ? .3 : .2, x1: vr ? 2 : 4, y0: 0, title: vr ? 'F (نيوتن) — نصف القطر r (م)' : 'F (نيوتن) — الكتلة m (كجم)' });
      ctx.fillStyle = COL.d; ctx.beginPath(); ctx.arc(o.sx(vr ? S.p.r : S.p.m), o.sy(F), 6, 0, TAU); ctx.fill();
    }
  });
};

SIMS.statics = (root, pre) => {
  const mode = pre.mode, g = 9.8; let rd = {}, ang = 0;
  return Sim(root, {
    h: 400, hm: 440, auto: mode !== 'tension',
    init(S) {
      if (mode === 'lever') { S.slider('m1', 'الكتلة اليسرى', .5, 10, .5, 4, 'كجم', { d: 1 }); S.slider('d1', 'بُعدها عن المحور', .2, 2, .1, 1, 'م', { d: 1 }); S.slider('m2', 'الكتلة اليمنى', .5, 10, .5, 2, 'كجم', { d: 1 }); S.slider('d2', 'بُعدها عن المحور', .2, 2, .1, 1, 'م', { d: 1 }); rd.t1 = S.read('العزم الأيسر m₁·g·d₁', 'N·m'); rd.t2 = S.read('العزم الأيمن m₂·g·d₂', 'N·m'); rd.st = S.read('الحالة', '', 'hi'); S.note('يتزن الجسم دورانيًا عندما يتساوى مجموع العزوم باتجاه عقارب الساعة مع عكسها: m₁d₁ = m₂d₂.'); }
      else if (mode === 'cg') { S.slider('m1', 'الكتلة الأولى', 1, 5, .5, 2, 'كجم', { d: 1 }); S.slider('p1', 'موضعها على الساق', 0, 2, .1, .3, 'م', { d: 1 }); S.slider('m2', 'الكتلة الثانية', 1, 5, .5, 4, 'كجم', { d: 1 }); S.slider('p2', 'موضعها على الساق', 0, 2, .1, 1.6, 'م', { d: 1 }); S.slider('pv', 'موضع نقطة الارتكاز', 0, 2, .01, 1, 'م', { d: 2 }); rd.cg = S.read('مركز الثقل المحسوب', 'م', 'hi'); rd.st = S.read('الحالة', ''); S.note('مركز الثقل هو النقطة التي يمكن اعتبار وزن الجسم كله مؤثرًا فيها: x = Σ(m·x) / Σm. (الساق كتلتها 1 كجم ومنتظمة).'); }
      else { S.slider('m', 'كتلة الجسم المعلّق', 1, 20, 1, 10, 'كجم', { d: 0 }); S.slider('al', 'زاوية الحبل الأيسر مع السقف', 10, 80, 1, 45, '°', { d: 0 }); S.slider('be', 'زاوية الحبل الأيمن مع السقف', 10, 80, 1, 45, '°', { d: 0 }); rd.t1 = S.read('الشد T₁', 'N', 'hi'); rd.t2 = S.read('الشد T₂', 'N', 'hi'); rd.w = S.read('الوزن W = mg', 'N'); S.note('في حالة الاتزان: مجموع المركبات الرأسية للشد = الوزن، ومجموع المركبات الأفقية = صفر.'); }
    },
    reset(S) { ang = 0; }, onParam() { },
    step(S, dt) {
      if (mode === 'lever') { const tq = (S.p.m2 * S.p.d2 - S.p.m1 * S.p.d1) * g, tgt = clamp(tq * .8, -14, 14); ang += (tgt - ang) * Math.min(1, dt * 4); }
      if (mode === 'cg') { const cg = (S.p.m1 * S.p.p1 + S.p.m2 * S.p.p2 + 1 * 1) / (S.p.m1 + S.p.m2 + 1), tq = (cg - S.p.pv) * (S.p.m1 + S.p.m2 + 1) * g, tgt = clamp(tq * .8, -14, 14); ang += (tgt - ang) * Math.min(1, dt * 4); }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const cx = W / 2, cy = H * .55;
      if (mode === 'lever') {
        const u = Math.min(W / 5.4, 110), a = ang * D2R; ctx.fillStyle = '#9fb7e0'; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx - 30, cy + 80); ctx.lineTo(cx + 30, cy + 80); ctx.fill();
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(a); rrect(ctx, -2.1 * u, -8, 4.2 * u, 12, 4, '#d9a35f'); ctx.restore();
        const ends = [[-1, S.p.m1, S.p.d1, COL.a], [1, S.p.m2, S.p.d2, COL.b]]; ends.forEach(([sgn, m, d, col]) => { const x = cx + sgn * d * u * Math.cos(a), y = cy + sgn * d * u * Math.sin(a) - 8, w = 26 + m * 4; rrect(ctx, x - w / 2, y - w, w, w, 4, col); text(ctx, fmt(m, 1) + ' كجم', x, y - w / 2, { size: 11, color: '#06101f', weight: 700 }); });
        const t1 = S.p.m1 * g * S.p.d1, t2 = S.p.m2 * g * S.p.d2; rd.t1(t1); rd.t2(t2); rd.st(Math.abs(t1 - t2) < .01 ? '✔ متزن' : t1 > t2 ? 'يميل لليسار' : 'يميل لليمين');
      } else if (mode === 'cg') {
        const u = Math.min(W / 2.8, 150), a = ang * D2R, X0 = -1 * u; const cg = (S.p.m1 * S.p.p1 + S.p.m2 * S.p.p2 + 1) / (S.p.m1 + S.p.m2 + 1);
        const pvx = cx + (S.p.pv - 1) * u, pvy = cy; ctx.fillStyle = '#9fb7e0'; ctx.beginPath(); ctx.moveTo(pvx, pvy); ctx.lineTo(pvx - 26, pvy + 80); ctx.lineTo(pvx + 26, pvy + 80); ctx.fill();
        ctx.save(); ctx.translate(pvx, pvy); ctx.rotate(a); const px = p => (p - S.p.pv) * u; rrect(ctx, px(0), -9, 2 * u, 12, 4, '#d9a35f');
        [[S.p.p1, S.p.m1, COL.a], [S.p.p2, S.p.m2, COL.b]].forEach(([p, m, col]) => { const w = 22 + m * 5; rrect(ctx, px(p) - w / 2, -9 - w, w, w, 4, col); text(ctx, fmt(m, 1), px(p), -9 - w / 2, { size: 11, color: '#06101f', weight: 700 }); });
        ctx.fillStyle = COL.d; ctx.beginPath(); ctx.moveTo(px(cg), 2); ctx.lineTo(px(cg) - 8, 18); ctx.lineTo(px(cg) + 8, 18); ctx.fill(); ctx.restore();
        rd.cg(cg); rd.st(Math.abs(cg - S.p.pv) < .02 ? '✔ متزن (الارتكاز عند مركز الثقل)' : cg > S.p.pv ? 'يميل لليمين' : 'يميل لليسار');
      } else {
        const m = S.p.m, W_ = m * g, al = S.p.al * D2R, be = S.p.be * D2R, sn = Math.sin(al + be), T1 = W_ * Math.cos(be) / sn, T2 = W_ * Math.cos(al) / sn, ky = 40, ky2 = H * .6, s = Math.min(W * .4, 200);
        const ox = cx, oy = ky2; const lx = ox - s * Math.cos(al), ly = oy - s * Math.sin(al), rx = ox + s * Math.cos(be), ry = oy - s * Math.sin(be);
        ctx.fillStyle = '#31496e'; ctx.fillRect(10, Math.min(ly, ry) - 12, W - 20, 10); ctx.strokeStyle = '#dbe7ff'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(ox, oy); ctx.lineTo(rx, ry); ctx.stroke();
        const w = 30 + m * 2; rrect(ctx, ox - w / 2, oy, w, w, 5, COL.a); text(ctx, m + ' كجم', ox, oy + w / 2, { color: '#06101f', weight: 700, size: 12 });
        const k = 1.1; arrow(ctx, ox, oy, ox - T1 * Math.cos(al) * k * .9, oy - T1 * Math.sin(al) * k * .9, COL.b, 3.5); arrow(ctx, ox, oy, ox + T2 * Math.cos(be) * k * .9, oy - T2 * Math.sin(be) * k * .9, COL.c, 3.5); arrow(ctx, ox, oy + w / 2, ox, oy + w / 2 + W_ * k * .9, COL.d, 3.5);
        text(ctx, 'T₁', ox - T1 * Math.cos(al) * k * .9 - 12, oy - T1 * Math.sin(al) * k * .9, { color: COL.b, weight: 700 }); text(ctx, 'T₂', ox + T2 * Math.cos(be) * k * .9 + 12, oy - T2 * Math.sin(be) * k * .9, { color: COL.c, weight: 700 }); text(ctx, 'W', ox + 16, oy + w / 2 + W_ * k * .9, { color: COL.d, weight: 700 });
        rd.t1(T1, 1); rd.t2(T2, 1); rd.w(W_, 1);
      }
    }
  });
};

SIMS.attract = (root) => {
  let rd = {}; const G = 6.674e-11;
  return Sim(root, {
    h: 400, hm: 520, static: true,
    init(S) {
      S.select('case', 'الحالة', [['small', 'كتلتان على الأرض'], ['em', 'الأرض والقمر']], 'small'); S.noResetOnSelect = true;
      S.slider('m1', 'الكتلة الأولى', 1, 1000, 1, 100, 'كجم', { d: 0 }); S.slider('m2', 'الكتلة الثانية', 1, 1000, 1, 100, 'كجم', { d: 0 }); S.slider('r', 'المسافة بين مركزيهما', .1, 2, .05, .5, 'م', { d: 2 });
      rd.F = S.read('قوة التجاذب F = G·m₁·m₂ / r²', '', 'hi'); S.note('G = 6.674×10⁻¹¹ N·m²/kg². تتناسب القوة طرديًا مع حاصل ضرب الكتلتين وعكسيًا مع مربع المسافة؛ فإذا ضاعفت المسافة تقل القوة إلى الربع.');
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const wide = W >= 640, sw = wide ? W * .55 : W, sh = wide ? H : H * .55, cy = sh / 2;
      let m1 = S.p.m1, m2 = S.p.m2, r = S.p.r, F;
      if (S.p.case === 'em') { m1 = 5.97e24; m2 = 7.35e22; r = 3.84e8; F = G * m1 * m2 / r / r; } else F = G * m1 * m2 / r / r;
      const d = S.p.case === 'em' ? sw * .6 : 40 + (r / 2) * (sw - 140), x1 = sw / 2 - d / 2, x2 = sw / 2 + d / 2;
      const r1 = S.p.case === 'em' ? 38 : 12 + Math.cbrt(m1) * 2.5, r2 = S.p.case === 'em' ? 14 : 12 + Math.cbrt(m2) * 2.5;
      ctx.fillStyle = S.p.case === 'em' ? '#3b82f6' : COL.a; ctx.beginPath(); ctx.arc(x1, cy, r1, 0, TAU); ctx.fill(); ctx.fillStyle = S.p.case === 'em' ? '#cbd5e1' : COL.b; ctx.beginPath(); ctx.arc(x2, cy, r2, 0, TAU); ctx.fill();
      const L = clamp(Math.log10(F * 1e12 + 1) * 12, 14, 80); arrow(ctx, x1 + r1 + 4, cy, x1 + r1 + 4 + L, cy, COL.d, 4); arrow(ctx, x2 - r2 - 4, cy, x2 - r2 - 4 - L, cy, COL.d, 4);
      text(ctx, S.p.case === 'em' ? 'الأرض' : fmt(m1, 0) + ' كجم', x1, cy + r1 + 20, { size: 12 }); text(ctx, S.p.case === 'em' ? 'القمر' : fmt(m2, 0) + ' كجم', x2, cy + r2 + 20, { size: 12 });
      text(ctx, 'r = ' + (S.p.case === 'em' ? '3.84×10⁸ م' : fmt(r, 2) + ' م'), sw / 2, 30, { color: COL.dim });
      rd.F(F < .001 ? F.toExponential(2) + ' N' : fmt(F / 1e0, 3) + ' N', 3);
      if (S.p.case !== 'em') {
        const gx = wide ? sw : 0, gy = wide ? 0 : sh, gw = wide ? W - sw : W, gh = wide ? H : H - sh, g2 = new Graph(); g2.s[0] = [];
        for (let i = 0; i <= 40; i++) { const rr = .1 + 1.9 * i / 40; g2.s[0].push([rr, G * m1 * m2 / rr / rr * 1e9]); }
        const o = g2.draw(ctx, gx + 8, gy + 8, gw - 16, gh - 16, { x0: 0, x1: 2, y0: 0, y1: Math.max(1, G * m1 * m2 / .1 / .1 * 1e9 * .12), title: 'F (نانونيوتن) — المسافة r (م)' });
        ctx.fillStyle = COL.d; ctx.beginPath(); ctx.arc(o.sx(r), o.sy(Math.min(F * 1e9, 1e12)), 6, 0, TAU); ctx.fill();
      }
    }
  });
};

SIMS.track = (root, pre) => {
  const g = 9.8, Lx = 20; let b = {}, E0 = 0, rd = {}, prof;
  const profs = {
    1: x => x < 12 ? 8 * (1 - x / 12) ** 1.0 + 0.0 : 0,
    2: x => .06 * (x - 10) ** 2,
    3: x => 7.5 - .22 * x + (Math.cos(TAU * x / 7) - 1) * .9
  };
  const Y = x => profs[pre.shape](clamp(x, 0, Lx)), dY = x => (Y(x + .01) - Y(x - .01)) / .02;
  return Sim(root, {
    h: 420, hm: 480,
    init(S) {
      S.slider('m', 'كتلة الجسم', .5, 5, .5, 1, 'كجم', { d: 1 }); S.slider('mu', 'معامل الاحتكاك', 0, .3, .02, 0, '', { d: 2 }); S.slider('x0', 'نقطة الإفلات (مسافة أفقية)', 0, 14, .5, pre.shape === 2 ? 1 : 0.5, 'م', { d: 1, reset: true });
      rd.pe = S.read('الطاقة الكامنة PE = mgh', 'جول'); rd.ke = S.read('الطاقة الحركية KE = ½mv²', 'جول'); rd.me = S.read('الطاقة الميكانيكية PE + KE', 'جول', 'hi'); rd.q = S.read('الطاقة المبددة حرارة', 'جول');
      S.note('في غياب الاحتكاك تبقى الطاقة الميكانيكية ثابتة: تتحول الكامنة إلى حركية والعكس. مع الاحتكاك يتبدد جزء منها حرارة.');
    },
    reset(S) { b = { x: S.p.x0, u: 0 }; E0 = S.p.m * g * Y(b.x); },
    onParam(S, k) { if (k === 'm') S.reset(); },
    step(S, dt) {
      const s = dY(b.x), c = 1 / Math.sqrt(1 + s * s), sn = s * c; let acc = -g * sn;
      const fr = S.p.mu * g * c; if (Math.abs(b.u) < .03) { if (Math.abs(acc) <= fr) { b.u = 0; acc = 0; } else acc -= fr * Math.sign(acc); } else acc -= fr * Math.sign(b.u);
      b.u += acc * dt; b.x += b.u * c * dt; if (b.x < 0) { b.x = 0; b.u = Math.abs(b.u); } if (b.x > Lx) { b.x = Lx; b.u = -Math.abs(b.u); }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const bw = W - 150, bx = 20, by = H - 40, sc = Math.min(bw / Lx, (H - 80) / 9), X = x => bx + x * sc, Yp = y => by - y * sc;
      ctx.fillStyle = '#26364f'; ctx.beginPath(); ctx.moveTo(X(0), by + 20); for (let x = 0; x <= Lx; x += .1) ctx.lineTo(X(x), Yp(Y(x))); ctx.lineTo(X(Lx), by + 20); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#6aa0ff'; ctx.lineWidth = 3; ctx.beginPath(); for (let x = 0; x <= Lx; x += .1) x ? ctx.lineTo(X(x), Yp(Y(x))) : ctx.moveTo(X(x), Yp(Y(x))); ctx.stroke();
      const y = Y(b.x), s = dY(b.x), nx = -s / Math.sqrt(1 + s * s), ny = 1 / Math.sqrt(1 + s * s); const rr = 8 + S.p.m * 2.2;
      ctx.fillStyle = COL.a; ctx.beginPath(); ctx.arc(X(b.x) + nx * rr * sc * .0 + nx * rr, Yp(y) - ny * rr, rr, 0, TAU); ctx.fill();
      const pe = S.p.m * g * y, ke = .5 * S.p.m * (b.u * b.u), q = Math.max(0, E0 - pe - ke);
      rd.pe(pe, 1); rd.ke(ke, 1); rd.me(pe + ke, 1); rd.q(q, 1);
      const bx0 = W - 120, bh = H - 100, mx = Math.max(E0, 1) * 1.05;
      [['PE', pe, COL.b], ['KE', ke, COL.a], ['حرارة', q, COL.d]].forEach(([n, v, col], i) => { const h = v / mx * bh; ctx.fillStyle = col; ctx.fillRect(bx0 + i * 36, 40 + bh - h, 26, h); text(ctx, n, bx0 + i * 36 + 13, 40 + bh + 14, { size: 11, color: COL.dim }); });
      text(ctx, 'الطاقة', bx0 + 50, 22, { weight: 700 });
    }
  });
};

SIMS.work = (root, pre) => {
  const g = 9.8, ke = pre.mode === 'ke'; let st = { x: 0, v: 0 }, rd = {};
  return Sim(root, {
    h: 330, hm: 380, auto: ke,
    init(S) {
      if (ke) { S.slider('m', 'كتلة الجسم', 1, 20, 1, 4, 'كجم', { d: 0 }); S.slider('v', 'سرعة الجسم', 0, 12, .5, 3, 'م/ث', { d: 1 }); rd.ke = S.read('KE = ½ m v²', 'جول', 'hi'); rd.p = S.read('عند مضاعفة السرعة تصبح KE', 'جول'); S.note('الطاقة الحركية تتناسب طرديًا مع الكتلة وطرديًا مع مربع السرعة: مضاعفة السرعة تضاعف الطاقة أربع مرات.'); }
      else { S.slider('F', 'القوة F', 5, 100, 5, 40, 'N', { d: 0 }); S.slider('th', 'زاوية القوة مع الأفقي', 0, 70, 5, 30, '°', { d: 0 }); S.slider('d', 'مسافة الحركة', 1, 15, 1, 8, 'م', { d: 0 }); S.slider('m', 'الكتلة', 1, 20, 1, 5, 'كجم', { d: 0 }); S.slider('mu', 'معامل الاحتكاك', 0, .4, .05, .1, '', { d: 2 }); rd.wf = S.read('شغل القوة F cos θ · x', 'جول', 'hi'); rd.wfr = S.read('شغل الاحتكاك', 'جول'); rd.k = S.read('الطاقة الحركية الناتجة', 'جول'); S.note('الشغل W = F · d · cos θ . الشغل الكلي (الصافي) = التغير في الطاقة الحركية.'); }
    },
    reset(S) { st = { x: 0, v: 0 }; },
    onParam(S) { if (!ke) S.reset(); },
    step(S, dt) {
      if (ke) { st.x += S.p.v * dt; return; }
      const th = S.p.th * D2R, N = Math.max(0, S.p.m * g - S.p.F * Math.sin(th)), fx = S.p.F * Math.cos(th) - S.p.mu * N; if (st.v > 0 || fx > 0) st.v = Math.max(0, st.v + fx / S.p.m * dt); st.x += st.v * dt; if (st.x >= S.p.d) { st.x = S.p.d; S.setRun(false); }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const y = H * .7; ctx.fillStyle = '#26364f'; ctx.fillRect(0, y, W, 40); const bw = 50 + S.p.m * 1.5;
      if (ke) {
        const off = st.x * 30; for (let x = -(off % 60); x < W; x += 60) { ctx.fillStyle = '#35507a'; ctx.fillRect(x, y, 3, 40); }
        rrect(ctx, W / 2 - bw / 2, y - bw, bw, bw, 6, COL.a); text(ctx, S.p.m + ' كجم', W / 2, y - bw / 2, { color: '#06101f', weight: 700 }); if (S.p.v > 0) arrow(ctx, W / 2, y - bw - 14, W / 2 + S.p.v * 12, y - bw - 14, COL.b, 3);
        const k = .5 * S.p.m * S.p.v ** 2; rd.ke(k, 1); rd.p(4 * k, 1);
        const mx = .5 * 20 * 144; ctx.fillStyle = 'rgba(255,255,255,.1)'; ctx.fillRect(40, 40, W - 80, 16); ctx.fillStyle = COL.b; ctx.fillRect(40, 40, (W - 80) * k / mx, 16); text(ctx, 'KE = ½ × ' + S.p.m + ' × ' + fmt(S.p.v, 1) + '² = ' + fmt(k, 1) + ' J', W / 2, 74, { size: 13 });
      } else {
        const sc = (W - 140) / 15, x0 = 70 + st.x * sc, th = S.p.th * D2R; ctx.fillStyle = 'rgba(255,255,255,.2)'; ctx.fillRect(70 + S.p.d * sc - 1, y - 90, 2, 90); text(ctx, 'خط النهاية', 70 + S.p.d * sc, y - 100, { size: 11, color: COL.dim });
        rrect(ctx, x0 - bw / 2, y - bw, bw, bw, 6, COL.a); text(ctx, S.p.m + ' كجم', x0, y - bw / 2, { color: '#06101f', weight: 700 }); arrow(ctx, x0, y - bw / 2, x0 + Math.cos(th) * S.p.F * 1.2, y - bw / 2 - Math.sin(th) * S.p.F * 1.2, COL.c, 4);
        const N = Math.max(0, S.p.m * g - S.p.F * Math.sin(th)), wf = S.p.F * Math.cos(th) * st.x, wfr = -S.p.mu * N * st.x; rd.wf(wf, 1); rd.wfr(wfr, 1); rd.k(.5 * S.p.m * st.v ** 2, 1);
        text(ctx, 'x = ' + fmt(st.x, 1) + ' م', W / 2, 30, { color: COL.dim });
      }
    }
  });
};

SIMS.lift = (root) => {
  let rd = {}, hh = 0;
  return Sim(root, {
    h: 430, hm: 470,
    init(S) {
      S.slider('m', 'كتلة الجسم', 1, 50, 1, 10, 'كجم', { d: 0 }); S.slider('h', 'ارتفاع الرفع', .5, 20, .5, 8, 'م', { d: 1 }); S.select('pl', 'الكوكب', [['9.81', 'الأرض'], ['1.62', 'القمر'], ['3.73', 'المريخ']], '9.81'); S.noResetOnSelect = true;
      rd.W = S.read('الوزن W = m·g', 'N'); rd.pe = S.read('الطاقة الكامنة PE = m·g·h', 'جول', 'hi'); S.note('الطاقة الكامنة التثاقلية تتناسب طرديًا مع الكتلة ومع الارتفاع ومع تسارع الجاذبية.');
    },
    reset(S) { hh = 0; }, onParam(S) { },
    step(S, dt) { hh = Math.min(S.p.h, hh + 3 * dt); if (hh >= S.p.h) S.setRun(false); },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const gnd = H - 40, top = 70, sc = (gnd - top) / 20, cx = W * .4; ctx.fillStyle = '#1d3a2a'; ctx.fillRect(0, gnd, W, 40);
      const hCur = S.running || S.t > 0 ? hh : 0; const y = gnd - hCur * sc; const w = 30 + S.p.m * .7;
      ctx.fillStyle = '#31496e'; ctx.fillRect(cx - 4, 30, 8, gnd - 30); ctx.fillRect(cx - 4, 30, 90, 8); ctx.strokeStyle = '#dbe7ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx + 80, 38); ctx.lineTo(cx + 80, y - w); ctx.stroke();
      rrect(ctx, cx + 80 - w / 2, y - w, w, w, 5, COL.a); text(ctx, S.p.m + ' كجم', cx + 80, y - w / 2, { color: '#06101f', weight: 700, size: 12 });
      ctx.strokeStyle = COL.dim; ctx.beginPath(); ctx.moveTo(cx + 190, gnd); ctx.lineTo(cx + 190, gnd - S.p.h * sc); ctx.stroke(); arrow(ctx, cx + 190, gnd, cx + 190, gnd - S.p.h * sc, COL.c, 2); text(ctx, 'h = ' + S.p.h + ' م', cx + 230, gnd - S.p.h * sc / 2, { color: COL.c });
      const g = +S.p.pl, pe = S.p.m * g * hCur; rd.W(S.p.m * g, 1); rd.pe(S.p.m * g * S.p.h, 1);
      text(ctx, 'الطاقة المخزّنة الآن = ' + fmt(pe, 0) + ' جول', W - 140, 40, { weight: 700, color: COL.b }); const mx = 50 * 24.79 * 20 * .5; ctx.fillStyle = 'rgba(255,255,255,.1)'; ctx.fillRect(W - 60, 60, 24, gnd - 90); ctx.fillStyle = COL.b; const hh2 = (gnd - 90) * Math.min(1, pe / mx); ctx.fillRect(W - 60, 60 + (gnd - 90) - hh2, 24, hh2);
    }
  });
};

SIMS.elastic = (root) => {
  let rd = {}, ph = 0, xb = 0, vb = 0;
  return Sim(root, {
    h: 360, hm: 400,
    init(S) {
      S.slider('x0', 'مقدار الانضغاط x', .05, .5, .05, .3, 'م', { d: 2, reset: true }); S.slider('k', 'ثابت النابض k', 50, 500, 10, 200, 'N/m', { d: 0, reset: true }); S.slider('m', 'كتلة الجسم', .1, 2, .1, .5, 'كجم', { d: 1, reset: true });
      rd.pe = S.read('الطاقة الكامنة المرنة ½kx²', 'جول', 'hi'); rd.v = S.read('السرعة عند الانطلاق v = x√(k/m)', 'م/ث'); rd.f = S.read('القوة الابتدائية F = kx', 'N');
      S.note('الطاقة الكامنة المخزّنة في النابض المضغوط = ½kx²، وتتحول كلها إلى طاقة حركية للجسم (على سطح أملس).');
    },
    reset(S) { xb = -S.p.x0; vb = 0; ph = 0; }, onParam() { },
    step(S, dt) {
      const w = Math.sqrt(S.p.k / S.p.m);
      if (ph === 0) { const t = S.t; xb = -S.p.x0 * Math.cos(w * t); vb = S.p.x0 * w * Math.sin(w * t); if (xb >= 0) { ph = 1; xb = 0; vb = S.p.x0 * w; } } else { xb += vb * dt; if (xb > 1.2) S.setRun(false); }
    },
    draw(S) {
      const { ctx, W, H } = S; bg(ctx, W, H, 0); const y = H * .62, sc = (W - 140) / 1.9, wall = 40, X0 = wall + .5 * sc; ctx.fillStyle = '#26364f'; ctx.fillRect(0, y, W, 40); ctx.fillStyle = '#9fb7e0'; ctx.fillRect(0, y - 80, wall, 80);
      const bx = X0 + xb * sc, bw = 40 + S.p.m * 8; ctx.strokeStyle = '#cfe3ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(wall, y - 22); const n = 12, x1 = bx - bw / 2; for (let i = 0; i < n; i++) ctx.lineTo(wall + (x1 - wall) * (i + .5) / n, y - 22 + (i % 2 ? 14 : -14)); ctx.lineTo(x1, y - 22); ctx.stroke();
      rrect(ctx, bx - bw / 2, y - 20 - bw / 2, bw, bw, 6, COL.a); text(ctx, S.p.m + ' كجم', bx, y - 20, { color: '#06101f', weight: 700, size: 12 });
      ctx.setLineDash([4, 4]); ctx.strokeStyle = COL.dim; ctx.beginPath(); ctx.moveTo(X0, y - 100); ctx.lineTo(X0, y); ctx.stroke(); ctx.setLineDash([]); text(ctx, 'الطول الطبيعي', X0, y - 108, { size: 11, color: COL.dim });
      const pe = .5 * S.p.k * S.p.x0 ** 2, v0 = S.p.x0 * Math.sqrt(S.p.k / S.p.m); rd.pe(pe, 1); rd.v(v0); rd.f(S.p.k * S.p.x0, 1);
      const peNow = ph === 0 ? .5 * S.p.k * xb * xb : 0, keNow = .5 * S.p.m * vb * vb; ctx.fillStyle = COL.b; ctx.fillRect(W - 90, 40, 24, 100 * peNow / pe); ctx.fillStyle = COL.a; ctx.fillRect(W - 60, 40, 24, 100 * keNow / pe); text(ctx, 'PE', W - 78, 160, { size: 11, color: COL.dim }); text(ctx, 'KE', W - 48, 160, { size: 11, color: COL.dim });
    }
  });
};
